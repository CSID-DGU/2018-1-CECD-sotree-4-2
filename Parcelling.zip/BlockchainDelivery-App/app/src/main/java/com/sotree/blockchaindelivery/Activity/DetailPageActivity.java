package com.sotree.blockchaindelivery.Activity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.sotree.blockchaindelivery.BuildConfig;
import com.sotree.blockchaindelivery.DTO.PackageDTO;
import com.sotree.blockchaindelivery.R;
import com.sotree.blockchaindelivery.Util;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Calendar;

public class DetailPageActivity extends AppCompatActivity {
    private static final String TAG = "DriverHistoryDetail";

    private PackageDTO mPackageDTO;
    private ProgressDialog mProgressDialog;
    private TextView mDateTextView;
    private TextView mStatusTextView;
    private TextView mSenderAddressATextView;
    private TextView mSenderAddressBTextView;
    private TextView mReceiverAddressATextView;
    private TextView mReceiverAddressBTextView;
    private ImageView mMainImageView;

    private String mEndDateString;

    @SuppressLint("StaticFieldLeak")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_page);

        mPackageDTO = getIntent().getParcelableExtra("package");

        Button packageMapButton = findViewById(R.id.activity_detail_page_btn_package_map);

        if (getIntent().getBooleanExtra("packageMap", false)) {
            if (getIntent().getBooleanExtra("take", false)) {
                packageMapButton.setText("인계 확인");
                packageMapButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(getApplicationContext(), PackageMapWithTakeActivity.class);
                        intent.putExtra("package", mPackageDTO);
                        startActivity(intent);
                        overridePendingTransition(0, 0);
                    }
                });
            } else {
                packageMapButton.setText("현재 위치 확인");
                packageMapButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(getApplicationContext(), PackageMapActivity.class);
                        intent.putExtra("package", mPackageDTO);
                        startActivity(intent);
                        overridePendingTransition(0, 0);
                    }
                });
            }
        } else {
            packageMapButton.setVisibility(View.GONE);
        }

        mDateTextView = findViewById(R.id.activity_driver_history_detail_tv_date);
        mStatusTextView = findViewById(R.id.activity_detail_page_tv_status);
        mSenderAddressATextView = findViewById(R.id.activity_driver_history_detail_tv_sender_address_a);
        mSenderAddressBTextView = findViewById(R.id.activity_driver_history_detail_tv_sender_address_b);
        mReceiverAddressATextView = findViewById(R.id.activity_driver_history_detail_tv_receiver_address_a);
        mReceiverAddressBTextView = findViewById(R.id.activity_driver_history_detail_tv_receiver_address_b);
        mMainImageView = findViewById(R.id.activity_driver_history_detail);

        TextView receiver = findViewById(R.id.activity_detail_page_tv_receiver);
        receiver.setText(mPackageDTO.getReceiverName());

        TextView price = findViewById(R.id.activity_detail_page_tv_price);
        price.setText(mPackageDTO.getPrice() + " 원");

        TextView weight = findViewById(R.id.activity_detail_page_tv_weight);
        weight.setText(Util.WEIGHT_ARRAY[mPackageDTO.getWeight()]);

        mStatusTextView.setText(Util.STATUS_ARRAY[mPackageDTO.getStatus()]);
        mSenderAddressATextView.setText(mPackageDTO.getSenderAddressA());
        mSenderAddressBTextView.setText(mPackageDTO.getSenderAddressB());
        mReceiverAddressATextView.setText(mPackageDTO.getReceiverAddressA());
        mReceiverAddressBTextView.setText(mPackageDTO.getReceiverAddressB());

        mProgressDialog = new ProgressDialog(DetailPageActivity.this);
        mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        mProgressDialog.setMessage("로드 중...");
        mProgressDialog.setCancelable(false);

        if (mPackageDTO.getStatus() == 0) {
            mDateTextView.setText("완료되지 않음");

            return;
        }

        mProgressDialog.show();

        new AsyncTask<Void, Void, Bitmap>() {
            @Override
            protected Bitmap doInBackground(Void... voids) {
                HttpURLConnection connection = null;

                try {
                    connection = (HttpURLConnection) new URL(BuildConfig.host_url + "/delivery/" + mPackageDTO.getDeliveryId()).openConnection();
                    connection.setRequestMethod("GET");
                    connection.setConnectTimeout(10000);
                    connection.setUseCaches(false);
                    connection.setDoInput(true);
                    connection.setUseCaches(false);
                    connection.setRequestProperty("Accept", "application/octet-stream");
                    connection.setRequestProperty("Content-Type", "application/json");

                    mEndDateString = connection.getHeaderField("x-date");

                    InputStream inputStream = connection.getInputStream();

                    Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                    inputStream.close();

                    return bitmap;
                } catch (IOException e) {
                    Log.e(TAG, Log.getStackTraceString(e));
                } finally {
                    if (connection != null) {
                        connection.disconnect();
                    }
                }

                return null;
            }

            @Override
            protected void onPostExecute(Bitmap aBitmap) {
                Calendar endDate = Calendar.getInstance();
                endDate.setTimeInMillis(Long.parseLong(mEndDateString) * 1000);

                mDateTextView.setText(endDate.get(Calendar.YEAR) + "." + (endDate.get(Calendar.MONTH) + 1) + "." + endDate.get(Calendar.DATE) + " 완료");
                mMainImageView.setImageBitmap(aBitmap);

                mProgressDialog.cancel();
            }
        }.execute();
    }

    @Override
    public void finish() {
        super.finish();

        overridePendingTransition(0, 0);
    }
}
