package com.sotree.blockchaindelivery.Connection.DTO;

import org.json.JSONObject;

public class HttpResponse {
    // HTTP 응답 DTO

    private int mStatusCode;
    private JSONObject mResponseBody;

    public HttpResponse(int statusCode, JSONObject responseBody) {
        mStatusCode = statusCode;
        mResponseBody = responseBody;
    }

    public int getStatusCode() {
        return mStatusCode;
    }

    public JSONObject getResponseBody() {
        return mResponseBody;
    }

    public String toString() {
        return mStatusCode + " " + mResponseBody;
    }

}
