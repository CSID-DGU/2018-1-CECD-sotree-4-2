package com.sotree.blockchaindelivery.Activity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.ProgressBar;

import com.sotree.blockchaindelivery.Connection.Api;
import com.sotree.blockchaindelivery.Connection.Connector;
import com.sotree.blockchaindelivery.Connection.DTO.HttpRequest;
import com.sotree.blockchaindelivery.Connection.DTO.HttpResponse;
import com.sotree.blockchaindelivery.Connection.HttpCallback;
import com.sotree.blockchaindelivery.R;
import com.sotree.blockchaindelivery.SharedPreferenceManager;

import java.io.IOException;
import java.util.HashMap;

public class AuthorizeActivity extends AppCompatActivity implements View.OnClickListener {
    // 드라이버 인증 화면

    private static final String TAG = "Authorize";
    private static final int PICK_FILE = 1;

    private ProgressBar mProgressBar;
    private ProgressDialog mProgressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_authorize);

        setSupportActionBar((Toolbar) findViewById(R.id.toolbar));
        getSupportActionBar().setTitle("인증 파일 업로드");

        mProgressBar = findViewById(R.id.progressbar);
        mProgressDialog = new ProgressDialog(AuthorizeActivity.this);
        mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        mProgressDialog.setMessage("업로드 중...");
        mProgressDialog.setCancelable(false);

        Button selectButton = findViewById(R.id.activity_authorize_btn_select);

        selectButton.setOnClickListener(this);
    }

    public void enableProgressBar() {
        mProgressBar.setVisibility(View.VISIBLE);
        mProgressDialog.show();
    }

    public void disableProgressBar() {
        mProgressBar.setVisibility(View.INVISIBLE);
        mProgressDialog.cancel();
    }

    @Override
    protected void onActivityResult(final int requestCode, int resultCode, Intent data) {
        if (resultCode != RESULT_OK || data == null) {
            return;
        }

        if (requestCode == PICK_FILE) {
            try {
                // 선택된 파일을 buffer[] 형식으로 형변환

                byte[] buffer = new byte[getContentResolver().openInputStream(data.getData()).available()];
                getContentResolver().openInputStream(data.getData()).read(buffer);

                // 버퍼 크기가 너무 크다면 토스트 알림
                if (buffer.length / 1000 / 1000 > 10) {
                    new AlertDialog.Builder(AuthorizeActivity.this).setMessage("파일 용량은 10MB를 넘지 않아야 합니다.").setPositiveButton("확인", null).show();
                    return;
                }

                // octet-stream 형식으로 서버에 문서 전송

                HashMap<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/octet-stream");
                headers.put("X-Content-Encoding", MimeTypeMap.getSingleton().getExtensionFromMimeType(getContentResolver().getType(data.getData())));

                HashMap<String, String> params = new HashMap<>();
                params.put("userId", SharedPreferenceManager.getInstance(AuthorizeActivity.this).getUserInformation().getUserId());

                HttpRequest request = new HttpRequest(Api.POST_AUTHORIZATION, headers, buffer, params);

                new Connector(
                        new Runnable() {
                            @Override
                            public void run() {
                                enableProgressBar();
                            }
                        },
                        null,
                        new HttpCallback() {
                            @Override
                            public void run(HttpResponse response) {
                                disableProgressBar();

                                switch (response.getStatusCode()) {
                                    case 201:
                                        // 서버 정상 응답 시 토스트 알림
                                        new AlertDialog.Builder(AuthorizeActivity.this).setMessage("파일이 업로드되었습니다.\n관리자의 승인을 기다리세요.").setPositiveButton("확인", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                finish();
                                                overridePendingTransition(0, 0);
                                            }
                                        }).show();
                                        break;
                                }
                            }
                        }
                ).connect(request);

            } catch (IOException e) {
                Log.e(TAG, Log.getStackTraceString(e));
            }
        }
    }

    @Override
    public void onClick(View v) {
        // 파일 선택 버튼 클릭 시 안드로이드의 파일 선택 화면 실행

        switch (v.getId()) {
            case R.id.activity_authorize_btn_select:
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");
                startActivityForResult(intent, PICK_FILE);
                overridePendingTransition(0, 0);
                break;
        }
    }
}
