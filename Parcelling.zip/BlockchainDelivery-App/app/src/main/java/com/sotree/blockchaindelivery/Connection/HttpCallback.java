package com.sotree.blockchaindelivery.Connection;

import com.sotree.blockchaindelivery.Connection.DTO.HttpResponse;

public interface HttpCallback {

    void run(HttpResponse response);
}
