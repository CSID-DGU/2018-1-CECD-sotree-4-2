package com.sotree.blockchaindelivery.Activity;

import android.Manifest;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.sotree.blockchaindelivery.Connection.Api;
import com.sotree.blockchaindelivery.Connection.Connector;
import com.sotree.blockchaindelivery.Connection.DTO.HttpRequest;
import com.sotree.blockchaindelivery.Connection.DTO.HttpResponse;
import com.sotree.blockchaindelivery.Connection.HttpCallback;
import com.sotree.blockchaindelivery.DTO.UserDTO;
import com.sotree.blockchaindelivery.GPSBroadcastReceiver;
import com.sotree.blockchaindelivery.R;
import com.sotree.blockchaindelivery.SharedPreferenceManager;

import org.json.JSONException;
import org.json.JSONObject;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {
    // 로그인 화면

    private static final String TAG = "Login";

    private SharedPreferenceManager mSharedPreferenceManager;

    private ProgressBar mProgressBar;

    private EditText mUserIdEditText;
    private EditText mUserPwEditText;

    private Button mLoginButton;
    private Button mRegisterButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mSharedPreferenceManager = SharedPreferenceManager.getInstance(LoginActivity.this);

        mProgressBar = findViewById(R.id.progressbar);

        mUserIdEditText = findViewById(R.id.activity_login_et_user_id);
        mUserPwEditText = findViewById(R.id.activity_login_et_user_pw);

        mLoginButton = findViewById(R.id.activity_login_btn_login);
        mRegisterButton = findViewById(R.id.activity_login_btn_register);

        mLoginButton.setOnClickListener(this);
        mRegisterButton.setOnClickListener(this);

        // 위치 정보 사용 승인(안드로이드 6.0 이후 보안 강화된 버전)
        if (ActivityCompat.checkSelfPermission(LoginActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(LoginActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(LoginActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 0);
        }

        if (!mSharedPreferenceManager.getUserInformation().getUserId().equals("")) {
            mUserIdEditText.setText(mSharedPreferenceManager.getUserInformation().getUserId());
            mUserPwEditText.setText(mSharedPreferenceManager.getUserInformation().getUserPw());
            mLoginButton.performClick();
        }
    }

    private void login() {
        // 로그인 버튼 클릭시 폼 확인
        if (!validateForm()) {
            Toast.makeText(LoginActivity.this, "아이디와 비밀번호를 바르게 입력하세요.", Toast.LENGTH_SHORT).show();
            return;
        }


        // JSON 객체에 로그인 정보 담아 전송
        JSONObject body = new JSONObject();
        try {
            body.put("userId", mUserIdEditText.getText().toString());
            body.put("userPw", mUserPwEditText.getText().toString());
        } catch (JSONException e) {
            Log.e(TAG, Log.getStackTraceString(e));
        }

        // 로그인 API 형식대로 전송
        HttpRequest request = new HttpRequest(Api.LOGIN, null, body);

        new Connector(
                new Runnable() {
                    @Override
                    public void run() {
                        startProgress();
                    }
                },
                null,
                new HttpCallback() {
                    @Override
                    public void run(HttpResponse response) {
                        switch (response.getStatusCode()) {
                            // HTTP 응답 값에 따라
                            case 201:
                                // 로그인 성공

                                String userName = "";
                                String userPhone = "";
                                int authorized = -1;

                                try {
                                    userName = response.getResponseBody().getString("userName");
                                    userPhone = response.getResponseBody().getString("userPhone");
                                    authorized = response.getResponseBody().getInt("authorized");
                                } catch (JSONException e) {
                                    Log.e(TAG, Log.getStackTraceString(e));
                                }

                                // 자동로그인을 위해 아이디와 비밀번호를 저장

                                UserDTO userDTO = new UserDTO(mUserIdEditText.getText().toString(), mUserPwEditText.getText().toString(), userName, userPhone, authorized);

                                mSharedPreferenceManager.login(userDTO);

                                ((AlarmManager) getSystemService(Context.ALARM_SERVICE)).setRepeating(AlarmManager.RTC_WAKEUP, System.currentTimeMillis(), 1000 * 60, PendingIntent.getBroadcast(getApplicationContext(), 0, new Intent(LoginActivity.this, GPSBroadcastReceiver.class), 0));

                                Intent intent = new Intent(LoginActivity.this, SelectRoleActivity.class);

                                intent.putExtra("authorized", authorized);

                                startActivity(intent);
                                finish();
                                overridePendingTransition(0, 0);
                                break;
                            case 400:
                                // 입력 에러

                                Toast.makeText(LoginActivity.this, "잘못 입력하셨습니다.", Toast.LENGTH_SHORT).show();
                                stopProgress();
                                break;
                            case 401:
                                // 비밀번호 에러

                                Toast.makeText(LoginActivity.this, "잘못된 비밀번호입니다.", Toast.LENGTH_SHORT).show();
                                stopProgress();
                                break;
                            case 404:
                                // 아이디 에러

                                Toast.makeText(LoginActivity.this, "존재하지 않는 아이디입니다.", Toast.LENGTH_SHORT).show();
                                stopProgress();
                                break;
                            case 500:
                                // 서버 오류

                                Toast.makeText(LoginActivity.this, "서버 오류입니다.", Toast.LENGTH_SHORT).show();
                                stopProgress();
                                break;
                        }
                    }
                }
        ).connect(request);
    }

    private void register() {
        // 가입 버튼 클릭시 가입 화면으로 이동

        Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
        startActivity(intent);
        overridePendingTransition(0, 0);
    }

    private boolean validateForm() {
        // 폼 체크

        String userId = mUserIdEditText.getText().toString();
        String userPw = mUserPwEditText.getText().toString();

        return !userId.equals("") && !userPw.equals("");
    }

    private void startProgress() {
        // 프로그레스 바 시작

        mProgressBar.setVisibility(View.VISIBLE);

        mUserIdEditText.setEnabled(false);
        mUserPwEditText.setEnabled(false);
        mLoginButton.setEnabled(false);
        mRegisterButton.setEnabled(false);
    }

    private void stopProgress() {
        // 프로그레스 바 종료

        mProgressBar.setVisibility(View.INVISIBLE);

        mUserIdEditText.setEnabled(true);
        mUserPwEditText.setEnabled(true);
        mLoginButton.setEnabled(true);
        mRegisterButton.setEnabled(true);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.activity_login_btn_login:
                login();
                break;
            case R.id.activity_login_btn_register:
                register();
                break;
        }
    }
}
