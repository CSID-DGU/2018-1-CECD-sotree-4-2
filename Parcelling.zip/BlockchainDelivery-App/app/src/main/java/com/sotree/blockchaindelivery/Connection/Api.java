package com.sotree.blockchaindelivery.Connection;

public enum Api {
    // 서버에 등록된 API 목록

    LOGIN("/login", "POST"),
    REGISTER("/users", "POST"),

    POST_AUTHORIZATION("/users/:userId/auth", "POST"),

    POST_PACKAGE("/packages", "POST"),
    POST_IMAGE("/packages/:packageId/images", "POST"),

    GET_PACKAGES_BY_SENDER("/packages/by-sender/:senderId", "GET"),
    GET_PROGRESS_PACKAGES_BY_SENDER("/packages/by-sender/:senderId/progress", "GET"),
    GET_FINISHED_PACKAGES_BY_SENDER("/packages/by-sender/:senderId/finished", "GET"),

    GET_AVAILABLE_PACKAGES("/packages/available", "GET"),
    GET_PROGRESS_PACKAGES_BY_DRIVER("/packages/by-driver/:driverId/progress", "GET"),
    GET_FINISHED_PACKAGES_BY_DRIVER("/packages/by-driver/:driverId/finished", "GET"),

    POST_DELIVERY("/delivery", "POST"),
    PATCH_DELIVERY("/delivery/:deliveryId", "PATCH"),
    PATCH_POSITION("/position/:driverId", "PATCH");

    private String mUrl;
    private String mMethod;

    Api(String url, String method) {
        mUrl = url;
        mMethod = method;
    }

    public String getUrl() {
        return mUrl;
    }

    public String getMethod() {
        return mMethod;
    }

    @Override
    public String toString() {
        return mMethod + " " + mUrl;
    }
}
