package com.sotree.blockchaindelivery.Activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import com.sotree.blockchaindelivery.R;
import com.sotree.blockchaindelivery.SharedPreferenceManager;

public class SelectRoleActivity extends AppCompatActivity implements View.OnClickListener {
    // 사용자/드라이버 선택 화면

    private SharedPreferenceManager mSharedPreferenceManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_role);

        mSharedPreferenceManager = SharedPreferenceManager.getInstance(this);

        Button senderButton = findViewById(R.id.activity_select_role_btn_sender);
        Button driverButton = findViewById(R.id.activity_select_role_btn_driver);

        senderButton.setOnClickListener(this);
        driverButton.setOnClickListener(this);

        switch (mSharedPreferenceManager.getRole()) {
            case "sender":
                senderButton.performClick();
                break;
            case "driver":
                driverButton.performClick();
                break;
        }
    }

    public void moveToSenderActivity() {
        // 사용자 선택 시 사용자 화면으로 이동

        Intent intent = new Intent(SelectRoleActivity.this, MainActivity.class);
        intent.putExtra("role", "sender");
        startActivity(intent);
        finish();
        overridePendingTransition(0, 0);
    }

    public void moveToDriverActivity() {
        // 드라이버 선택시 인증되었는지 확인

        switch (getIntent().getIntExtra("authorized", -1)) {
            case -1:
                // 인증되지 않았으면 인증 화면으로 이동
                new AlertDialog.Builder(SelectRoleActivity.this).setMessage("인증되지 않았습니다.\n인증 화면으로 이동합니다.").setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(SelectRoleActivity.this, AuthorizeActivity.class);
                        startActivity(intent);
                        overridePendingTransition(0, 0);
                    }
                }).create().show();
                break;
            case 0:
                // 인증 대기중이면 토스트 알림
                new AlertDialog.Builder(SelectRoleActivity.this).setMessage("인증 대기중입니다.\n관리자의 확인 후 이용하실 수 있습니다.").setPositiveButton("확인", null).create().show();
                break;
            case 1:
                // 인증되었으면 드라이버 화면으로 이동
                Intent intent = new Intent(SelectRoleActivity.this, MainActivity.class);
                intent.putExtra("role", "driver");
                startActivity(intent);
                finish();
                overridePendingTransition(0, 0);
                break;
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.activity_select_role_btn_sender:
                mSharedPreferenceManager.setRole("sender");
                moveToSenderActivity();
                break;
            case R.id.activity_select_role_btn_driver:
                mSharedPreferenceManager.setRole("driver");
                moveToDriverActivity();
                break;
            default:
                break;
        }
    }
}
