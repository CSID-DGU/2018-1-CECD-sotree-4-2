package com.sotree.blockchaindelivery.ListView.Adapter;

import android.widget.BaseAdapter;

import java.util.ArrayList;
import java.util.List;

public abstract class ListViewAdapter<T> extends BaseAdapter {
    // 리스트 객체를 GUI로 표시하는 어댑터

    private List<T> mDataList;
    private List<T> mBufferList;

    public ListViewAdapter() {
        mDataList = new ArrayList<>();
        mBufferList = new ArrayList<>();
    }

    public void addItem(T item) {
        mDataList.add(item);
    }

    @Override
    public void notifyDataSetChanged() {
        mDataList.clear();
        mDataList = mBufferList;
        mBufferList = new ArrayList<>();

        super.notifyDataSetChanged();
    }

    public void clear() {
        mDataList.clear();
    }

    public void addBuffer(T item) {
        mBufferList.add(item);
    }

    public int getBufferCount() {
        return mBufferList.size();
    }

    @Override
    public int getCount() {
        return mDataList.size();
    }

    @Override
    public T getItem(int position) {
        return mDataList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
}
