package com.sotree.blockchaindelivery.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ProgressBar;

import com.sotree.blockchaindelivery.Activity.DetailPageActivity;
import com.sotree.blockchaindelivery.Connection.Api;
import com.sotree.blockchaindelivery.Connection.Connector;
import com.sotree.blockchaindelivery.Connection.DTO.HttpRequest;
import com.sotree.blockchaindelivery.Connection.DTO.HttpResponse;
import com.sotree.blockchaindelivery.Connection.HttpCallback;
import com.sotree.blockchaindelivery.DTO.PackageDTO;
import com.sotree.blockchaindelivery.ListView.Adapter.PackageListViewAdapter;
import com.sotree.blockchaindelivery.R;
import com.sotree.blockchaindelivery.SharedPreferenceManager;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.HashMap;

public class SenderProgressFragment extends Fragment implements SwipeRefreshLayout.OnRefreshListener {

    private static final String TAG = "SenderProgress";
    private ProgressBar mProgressBar;
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private PackageListViewAdapter mAdapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_sender_progress, container, false);

        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("배송중인 택배");

        mProgressBar = getActivity().findViewById(R.id.progressbar);

        mSwipeRefreshLayout = rootView.findViewById(R.id.activity_sender_progress_refresh_layout);
        mSwipeRefreshLayout.setOnRefreshListener(this);

        mAdapter = new PackageListViewAdapter();

        ListView listView = rootView.findViewById(R.id.activity_sender_progress_listview);
        listView.setAdapter(mAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (mAdapter.getItem(position).getStatus() == 1) {
                    Intent intent = new Intent(getActivity(), DetailPageActivity.class);
                    intent.putExtra("package", mAdapter.getItem(position));
                    intent.putExtra("packageMap", true);
                    intent.putExtra("take", true);
                    startActivity(intent);
                    getActivity().overridePendingTransition(0, 0);
                } else if (mAdapter.getItem(position).getStatus() == 0 || mAdapter.getItem(position).getStatus() == 4) {
                    Intent intent = new Intent(getActivity(), DetailPageActivity.class);
                    intent.putExtra("package", mAdapter.getItem(position));
                    startActivity(intent);
                    getActivity().overridePendingTransition(0, 0);
                } else {
                    Intent intent = new Intent(getActivity(), DetailPageActivity.class);
                    intent.putExtra("package", mAdapter.getItem(position));
                    intent.putExtra("packageMap", true);
                    startActivity(intent);
                    getActivity().overridePendingTransition(0, 0);
                }
            }
        });

        loadData();

        return rootView;
    }

    @Override
    public void onRefresh() {
        loadData();
    }

    private void loadData() {
        HashMap<String, String> params = new HashMap<>();
        params.put("senderId", SharedPreferenceManager.getInstance(getActivity()).getUserInformation().getUserId());

        // 진행 목록 API로 연결하여 데이터 받아옴
        HttpRequest request = new HttpRequest(Api.GET_PACKAGES_BY_SENDER, null, null, params);

        new Connector(
                new Runnable() {
                    @Override
                    public void run() {
                        enableProgressBar();
                    }
                },
                new HttpCallback() {
                    @Override
                    public void run(HttpResponse response) {
                        try {
                            JSONArray dataArray = response.getResponseBody().getJSONArray("data");

                            // 받은 데이터를 리스트에 추가

                            for (int i = 0; i < dataArray.length(); i++) {
                                PackageDTO packageDTO = new PackageDTO(dataArray.getJSONObject(i));
                                packageDTO.setLocation(getActivity());


                                if (packageDTO.getStatus() != 4) {
                                    mAdapter.addBuffer(packageDTO);
                                }
                            }
                        } catch (JSONException e) {
                            Log.e(TAG, Log.getStackTraceString(e));
                        }
                    }
                },
                new HttpCallback() {
                    @Override
                    public void run(HttpResponse response) {
                        disableProgressBar();
                        mSwipeRefreshLayout.setRefreshing(false);

                        if (mAdapter.getBufferCount() == 0) {
                            if (getView() != null) {
                                getView().findViewById(R.id.textView_no_content).setVisibility(View.VISIBLE);
                            }
                        } else {
                            if (getView() != null) {
                                getView().findViewById(R.id.textView_no_content).setVisibility(View.GONE);
                            }
                        }

                        mAdapter.notifyDataSetChanged();
                    }
                }
        ).connect(request);
    }

    private void enableProgressBar() {
        mProgressBar.setVisibility(View.VISIBLE);
    }

    private void disableProgressBar() {
        mProgressBar.setVisibility(View.INVISIBLE);
    }
}
