package com.sotree.blockchaindelivery.DTO;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.List;

public class PackageDTO implements Parcelable {
    public static final Creator<PackageDTO> CREATOR = new Creator<PackageDTO>() {
        @Override
        public PackageDTO createFromParcel(Parcel in) {
            return new PackageDTO(in);
        }

        @Override
        public PackageDTO[] newArray(int size) {
            return new PackageDTO[size];
        }
    };
    // 택배 객체 DTO
    private static final String TAG = "PackageDTO";
    private int mDeliveryId;
    private int mPackageId;
    private String mSenderId;
    private String mReceiverName;
    private String mSenderAddressA;
    private String mSenderAddressB;
    private String mReceiverAddressA;
    private String mReceiverAddressB;
    private int mDistance;
    private int mWeight;
    private int mPrice;
    private int mDeadline;
    private int mStatus;
    private String mCurrentPosition;

    private Location mSenderLocation;
    private Location mReceiverLocation;

    public PackageDTO(JSONObject data) throws JSONException {
        mDeliveryId = data.getInt("deliveryId");
        mPackageId = data.getInt("packageId");
        mSenderId = data.getString("senderId");
        mReceiverName = data.getString("receiverName");
        mSenderAddressA = data.getString("senderAddressA");
        mSenderAddressB = data.getString("senderAddressB");
        mReceiverAddressA = data.getString("receiverAddressA");
        mReceiverAddressB = data.getString("receiverAddressB");
        mDistance = data.getInt("distance");
        mWeight = data.getInt("weight");
        mPrice = data.getInt("price");
        mDeadline = data.getInt("deadline");
        mStatus = data.getInt("status");
        mCurrentPosition = data.getString("currentPosition");
    }

    public PackageDTO(Parcel parcel) {
        mDeliveryId = parcel.readInt();
        mPackageId = parcel.readInt();
        mSenderId = parcel.readString();
        mReceiverName = parcel.readString();
        mSenderAddressA = parcel.readString();
        mSenderAddressB = parcel.readString();
        mReceiverAddressA = parcel.readString();
        mReceiverAddressB = parcel.readString();
        mDistance = parcel.readInt();
        mWeight = parcel.readInt();
        mPrice = parcel.readInt();
        mDeadline = parcel.readInt();
        mStatus = parcel.readInt();
        mCurrentPosition = parcel.readString();
    }

    public void setLocation(Context context) {
        if (context == null) {
            return;
        }

        Geocoder geocoder = new Geocoder(context);

        Location senderLocation = new Location("sender");
        Location receiverLocation = new Location("receiver");

        List<Address> addressList = null;

        try {
            addressList = geocoder.getFromLocationName(mSenderAddressA + " " + mSenderAddressB, 1);
            if (addressList.size() > 0) {
                senderLocation.setLatitude(addressList.get(0).getLatitude());
                senderLocation.setLongitude(addressList.get(0).getLongitude());
            } else {
                senderLocation.setLatitude(0.0);
                senderLocation.setLongitude(0.0);
            }

            addressList = geocoder.getFromLocationName(mReceiverAddressA + " " + mReceiverAddressB, 1);
            if (addressList.size() > 0) {
                receiverLocation.setLatitude(addressList.get(0).getLatitude());
                receiverLocation.setLongitude(addressList.get(0).getLongitude());
            } else {
                senderLocation.setLatitude(0.0);
                senderLocation.setLongitude(0.0);
            }
        } catch (IOException e) {
            Log.e(TAG, Log.getStackTraceString(e));
        }

        mSenderLocation = senderLocation;
        mReceiverLocation = receiverLocation;
    }

    public int getDeliveryId() {
        return mDeliveryId;
    }

    public void setDeliveryId(int mDeliveryId) {
        this.mDeliveryId = mDeliveryId;
    }

    public int getPackageId() {
        return mPackageId;
    }

    public void setPackageId(int packageId) {
        mPackageId = packageId;
    }

    public String getSenderId() {
        return mSenderId;
    }

    public void setSenderId(String senderId) {
        mSenderId = senderId;
    }

    public int getWeight() {
        return mWeight;
    }

    public void setWeight(int weight) {
        mWeight = weight;
    }

    public String getSenderAddressA() {
        return mSenderAddressA;
    }

    public void setSenderAddressA(String senderAddressA) {
        mSenderAddressA = senderAddressA;
    }

    public String getSenderAddressB() {
        return mSenderAddressB;
    }

    public void setSenderAddressB(String senderAddressB) {
        mSenderAddressB = senderAddressB;
    }

    public String getReceiverAddressA() {
        return mReceiverAddressA;
    }

    public void setReceiverAddressA(String receiverAddressA) {
        mReceiverAddressA = receiverAddressA;
    }

    public String getReceiverAddressB() {
        return mReceiverAddressB;
    }

    public void setReceiverAddressB(String receiverAddressB) {
        mReceiverAddressB = receiverAddressB;
    }

    public String getReceiverName() {
        return mReceiverName;
    }

    public void setReceiverName(String receiverName) {
        mReceiverName = receiverName;
    }

    public int getDistance() {
        return mDistance;
    }

    public void setDistance(int distance) {
        mDistance = distance;
    }

    public int getPrice() {
        return mPrice;
    }

    public void setPrice(int price) {
        mPrice = price;
    }

    public int getDeadline() {
        return mDeadline;
    }

    public void setDeadline(int deadline) {
        mDeadline = deadline;
    }

    public String getCurrentPosition() {
        return mCurrentPosition;
    }

    public void setCurrentPosition(String currentPosition) {
        mCurrentPosition = currentPosition;
    }

    public int getStatus() {
        return mStatus;
    }

    public void setStatus(int status) {
        mStatus = status;
    }

    public Location getSenderLocation() {
        return mSenderLocation;
    }

    public Location getReceiverLocation() {
        return mReceiverLocation;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(mDeliveryId);
        dest.writeInt(mPackageId);
        dest.writeString(mSenderId);
        dest.writeString(mReceiverName);
        dest.writeString(mSenderAddressA);
        dest.writeString(mSenderAddressB);
        dest.writeString(mReceiverAddressA);
        dest.writeString(mReceiverAddressB);
        dest.writeInt(mDistance);
        dest.writeInt(mWeight);
        dest.writeInt(mPrice);
        dest.writeInt(mDeadline);
        dest.writeInt(mStatus);
        dest.writeString(mCurrentPosition);
    }
}
