package com.sotree.blockchaindelivery.Activity;

import android.content.Context;
import android.content.Intent;
import android.location.Geocoder;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.Toast;

import com.sotree.blockchaindelivery.Fragment.DriverAvailableFragment;
import com.sotree.blockchaindelivery.Fragment.DriverFinishedFragment;
import com.sotree.blockchaindelivery.Fragment.DriverMainFragment;
import com.sotree.blockchaindelivery.Fragment.DriverProgressFragment;
import com.sotree.blockchaindelivery.Fragment.SenderFinishedFragment;
import com.sotree.blockchaindelivery.Fragment.SenderMainFragment;
import com.sotree.blockchaindelivery.Fragment.SenderProgressFragment;
import com.sotree.blockchaindelivery.Fragment.SenderRegisterFragment;
import com.sotree.blockchaindelivery.R;
import com.sotree.blockchaindelivery.SharedPreferenceManager;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    public static final int REQUEST_EXIT_CODE = 12;

    public static Geocoder geocoder = null;
    public static LocationManager locationManager = null;
    // 사용자 메인 화면
    private String mRole = "";

    private long mBackButtonClickedTimeMills = 0;

    private NavigationView navigationView = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mRole = getIntent().getStringExtra("role");

        if (mRole.equals("sender")) {
            setContentView(R.layout.activity_sender);

            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.container, new SenderMainFragment())
                    .commit();
        } else {
            setContentView(R.layout.activity_driver);

            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.container, new DriverMainFragment())
                    .commit();
        }

        Toolbar toolbar = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("사용자 메뉴");

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        navigationView = findViewById(R.id.menu);
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.getMenu().getItem(0).setChecked(true);

        if (geocoder == null) {
            geocoder = new Geocoder(MainActivity.this);
        }

        if (locationManager == null) {
            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        }
    }

    @Override
    public void onBackPressed() {
        if (System.currentTimeMillis() - mBackButtonClickedTimeMills > 3000) {
            mBackButtonClickedTimeMills = System.currentTimeMillis();

            Toast.makeText(MainActivity.this, "뒤로 가기 버튼을 다시 누르면 로그아웃됩니다.", Toast.LENGTH_SHORT).show();
        } else {
            SharedPreferenceManager.getInstance(MainActivity.this).logout();

            Toast.makeText(MainActivity.this, "로그아웃 되었습니다.", Toast.LENGTH_SHORT).show();

            startActivity(new Intent(MainActivity.this, LoginActivity.class));
            finish();
            overridePendingTransition(0, 0);
        }
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.sender_menu_main:
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.container, new SenderMainFragment())
                        .commit();
                break;
            case R.id.sender_menu_register:
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.container, new SenderRegisterFragment())
                        .commit();
                break;
            case R.id.sender_menu_progress:
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.container, new SenderProgressFragment())
                        .commit();
                break;
            case R.id.sender_menu_finished:
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.container, new SenderFinishedFragment())
                        .commit();
                break;
            case R.id.driver_menu_main:
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.container, new DriverMainFragment())
                        .commit();
                break;
            case R.id.driver_menu_available:
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.container, new DriverAvailableFragment())
                        .commit();
                break;
            case R.id.driver_menu_progress:
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.container, new DriverProgressFragment())
                        .commit();
                break;
            case R.id.driver_menu_finished:
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.container, new DriverFinishedFragment())
                        .commit();
                break;
            default:
                break;
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        switch (requestCode) {
            case REQUEST_EXIT_CODE:
                if (resultCode == 1) {
                    navigationView.getMenu().getItem(2).setChecked(true);

                    getSupportFragmentManager()
                            .beginTransaction()
                            .replace(R.id.container, new DriverMainFragment())
                            .commit();
                }
                break;
            default:
                break;
        }
    }
}
