package com.sotree.blockchaindelivery.Connection.DTO;

import com.sotree.blockchaindelivery.Connection.Api;

import java.util.Map;

public class HttpRequest {
    // HTTP 연결 DTO

    private Api mApi;
    private Map<String, String> mHeader;
    private Object mBody;
    private String mUrl;

    public HttpRequest(Api api) {
        mApi = api;
        mHeader = null;
        mBody = null;
    }

    public HttpRequest(Api api, Map<String, String> header, Object body) {
        mApi = api;
        mHeader = header;
        mBody = body;
        mUrl = api.getUrl();
    }

    public HttpRequest(Api api, Map<String, String> header, Object body, Map<String, String> params) {
        mApi = api;
        mHeader = header;
        mBody = body;
        mUrl = api.getUrl();

        if (params == null) {
            return;
        }

        StringBuilder buffer = new StringBuilder();

        for (String key : params.keySet()) {
            if (api.getUrl().contains(":" + key)) {
                mUrl = mUrl.replace(":" + key, params.get(key));
            } else {
                if (buffer.length() == 0) {
                    buffer.append(key).append("=").append(params.get(key));
                } else {
                    buffer.append("&").append(key).append("=").append(params.get(key));
                }
            }
        }

        if (buffer.length() == 0) {
            mUrl += "?" + buffer.toString();
        }
    }

    public Api getApi() {
        return mApi;
    }

    public Map<String, String> getHeader() {
        return mHeader;
    }

    public Object getBody() {
        return mBody;
    }

    public String getUrl() {
        return mUrl;
    }

    public String toString() {
        return mApi + " " + mBody;
    }
}
