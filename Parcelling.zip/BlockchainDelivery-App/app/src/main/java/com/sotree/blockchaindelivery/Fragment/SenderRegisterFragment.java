package com.sotree.blockchaindelivery.Fragment;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.sotree.blockchaindelivery.Activity.KakaoDemoActivity;
import com.sotree.blockchaindelivery.Activity.MainActivity;
import com.sotree.blockchaindelivery.Connection.Api;
import com.sotree.blockchaindelivery.Connection.Connector;
import com.sotree.blockchaindelivery.Connection.DTO.HttpRequest;
import com.sotree.blockchaindelivery.Connection.DTO.HttpResponse;
import com.sotree.blockchaindelivery.Connection.HttpCallback;
import com.sotree.blockchaindelivery.R;
import com.sotree.blockchaindelivery.SharedPreferenceManager;
import com.sotree.blockchaindelivery.Util;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static android.app.Activity.RESULT_OK;

public class SenderRegisterFragment extends Fragment implements View.OnClickListener {

    private static final String TAG = "SenderRegister";
    private static final int PICK_IMAGE = 1;
    private static final int KAKAODEMO = 2;
    private static final int MAX_IMAGE_COUNT = 5;

    private List<Uri> mImageList;
    private List<Boolean> mUploadStatus;

    private int mWeightIndex;
    private int mDeadLineIndex;

    private LinearLayout mImageContainer;
    private int mImageCount;
    private int mImageIndex;

    private ImageView[] mImageViews;
    private TextView mWeightTextView;
    private TextView mSenderAddressATextView;
    private TextView mSenderAddressBTextView;
    private TextView mReceiverAddressATextView;
    private TextView mReceiverAddressBTextView;
    private TextView mReceiverNameTextView;
    private TextView mDeadLineTextView;
    private TextView mDistanceTextView;
    public View.OnFocusChangeListener mOnFocusChangeListener = new View.OnFocusChangeListener() {
        @Override
        public void onFocusChange(View v, boolean hasFocus) {
            // 주소 입력 시 자동으로 배송 시작-수신지 간 거리 계산

            if (mSenderAddressATextView.getText().length() == 0 || mSenderAddressBTextView.getText().length() == 0 || mReceiverAddressATextView.getText().length() == 0 || mReceiverAddressBTextView.getText().length() == 0 || hasFocus) {
                return;
            }

            try {
                float p = parseAddress();
                Log.e("TAG", String.valueOf(p));
                mDistanceTextView.setText(p + " km");
            } catch (IOException e) {
                mDistanceTextView.setText("- km");
            }
        }
    };
    private TextView mReceiverPhoneTextView;
    private TextView mPriceTextView;
    private AlertDialog mPriceDialog;
    private AlertDialog mWeightPickerDialog;
    private AlertDialog mDeadLinePickerDialog;
    private ProgressDialog mProgressDialog;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_sender_register, container, false);

        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("택배 등록");

        mPriceDialog = new AlertDialog.Builder(getActivity()).setView(R.layout.dialog_price).setTitle("가격 책정").setPositiveButton("확인", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                EditText mPriceEditText = mPriceDialog.findViewById(R.id.dialog_price_et);

                if (mPriceEditText.length() == 0) {
                    mPriceEditText.setText("0test");
                }

                mPriceTextView.setText(mPriceEditText.getText() + " 원");
            }
        }).create();

        mWeightPickerDialog = new AlertDialog.Builder(getActivity()).setItems(Util.WEIGHT_ARRAY, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                mWeightIndex = which;
                mWeightTextView.setText(Util.WEIGHT_ARRAY[mWeightIndex]);
            }
        }).create();
        mDeadLinePickerDialog = new AlertDialog.Builder(getActivity()).setItems(Util.DEADLINE_ARRAY, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                mDeadLineIndex = which;
                mDeadLineTextView.setText(Util.DEADLINE_ARRAY[mDeadLineIndex]);
            }
        }).create();

        mProgressDialog = new ProgressDialog(getActivity());
        mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        mProgressDialog.setMessage("택배 등록 중...");
        mProgressDialog.setCancelable(false);

        mImageList = new ArrayList<>();
        mUploadStatus = new ArrayList<>();

        mWeightIndex = 0;
        mDeadLineIndex = 0;

        mImageContainer = rootView.findViewById(R.id.activity_sender_register_image_container);
        mImageViews = new ImageView[MAX_IMAGE_COUNT];
        mImageIndex = 0;
        mImageCount = 0;

        mWeightTextView = rootView.findViewById(R.id.activity_sender_register_tv_weight);
        mWeightTextView.setText(Util.WEIGHT_ARRAY[mWeightIndex]);
        mWeightTextView.setOnClickListener(this);

        mSenderAddressATextView = rootView.findViewById(R.id.activity_sender_register_et_sender_address_a);
        mSenderAddressBTextView = rootView.findViewById(R.id.activity_sender_register_et_sender_address_b);

        mReceiverAddressATextView = rootView.findViewById(R.id.activity_sender_register_et_receiver_address_a);
        mReceiverAddressBTextView = rootView.findViewById(R.id.activity_sender_register_et_receiver_address_b);

        mReceiverNameTextView = rootView.findViewById(R.id.activity_sender_register_et_receiver_name);
        mReceiverPhoneTextView = rootView.findViewById(R.id.activity_sender_register_et_receiver_phone);

        mDeadLineTextView = rootView.findViewById(R.id.activity_sender_register_tv_deadline);
        mDeadLineTextView.setText(Util.DEADLINE_ARRAY[mDeadLineIndex]);
        mDeadLineTextView.setOnClickListener(this);

        mDistanceTextView = rootView.findViewById(R.id.activity_sender_register_tv_distance);
        mPriceTextView = rootView.findViewById(R.id.activity_sender_register_tv_price);

        mPriceTextView.setOnClickListener(this);

        Button registerButton = rootView.findViewById(R.id.activity_sender_register_btn_register);
        registerButton.setOnClickListener(this);

        addDefaultImageView();

        mSenderAddressATextView.setOnFocusChangeListener(mOnFocusChangeListener);
        mSenderAddressBTextView.setOnFocusChangeListener(mOnFocusChangeListener);
        mReceiverAddressATextView.setOnFocusChangeListener(mOnFocusChangeListener);
        mReceiverAddressBTextView.setOnFocusChangeListener(mOnFocusChangeListener);

        return rootView;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode != RESULT_OK || data == null) {
            return;
        }

        if (requestCode == PICK_IMAGE) {
            try {
                mImageList.add(data.getData());
                mUploadStatus.add(Boolean.FALSE);

                mImageViews[mImageIndex].setImageDrawable(Drawable.createFromStream(getActivity().getContentResolver().openInputStream(data.getData()), "image"));
                addDefaultImageView();
            } catch (IOException e) {
                Log.e(TAG, Log.getStackTraceString(e));
            }
        } else if (requestCode == KAKAODEMO) {
            if (data.getBooleanExtra("result", false)) {
                register();
            } else {
                Toast.makeText(getActivity(), "결제가 취소되었습니다.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();

        // 이미지 5장 업로드 후 버튼 비활성화
        // 아직 5장 전이라면 안드로이드의 이미지 업로드 화면으로 이동

        if (id < MAX_IMAGE_COUNT) {
            mImageIndex = id;

            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("image/*");
            startActivityForResult(intent, PICK_IMAGE);
            getActivity().overridePendingTransition(0, 0);

            return;
        }

        switch (v.getId()) {
            case R.id.activity_sender_register_tv_weight:
                mWeightPickerDialog.show();
                break;
            case R.id.activity_sender_register_tv_deadline:
                mDeadLinePickerDialog.show();
                break;
            case R.id.activity_sender_register_tv_price:
                mPriceDialog.show();
                break;
            case R.id.activity_sender_register_btn_register:
                if (!validateForm()) {
                    break;
                }

                Intent intent = new Intent(getActivity(), KakaoDemoActivity.class);
                intent.putExtra("price", Integer.parseInt(mPriceTextView.getText().toString().substring(0, mPriceTextView.getText().toString().length() - 2)));
                startActivityForResult(intent, KAKAODEMO);
                getActivity().overridePendingTransition(0, 0);
                break;
        }
    }

    public void enableProgressBar() {
        mProgressDialog.show();
    }

    public void disableProgressBar() {
        mProgressDialog.cancel();
    }

    private void addDefaultImageView() {
        // 기본 이미지 추가 버튼 (+모양) 생성

        if (mImageCount >= MAX_IMAGE_COUNT) {
            return;
        }

        TypedValue outValue = new TypedValue();
        getActivity().getTheme().resolveAttribute(android.R.attr.selectableItemBackground, outValue, true);

        final float scale = getResources().getDisplayMetrics().density;
        final int viewSizeDp = 80;
        final int marginSizeDp = 8;
        int viewSizePixel = (int) (viewSizeDp * scale + 0.5f);
        int marginSizePixel = (int) (marginSizeDp * scale + 0.5f);

        ImageView imageView = new ImageView(getActivity());
        imageView.setId(mImageCount);
        imageView.setOnClickListener(this);

        imageView.setImageResource(R.drawable.ic_add_black);
        imageView.setBackgroundResource(outValue.resourceId);

        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(viewSizePixel, viewSizePixel, 1.0f);
        layoutParams.setMargins(marginSizePixel, marginSizePixel, marginSizePixel, marginSizePixel);

        imageView.setLayoutParams(layoutParams);

        mImageContainer.addView(imageView);
        mImageViews[mImageCount++] = imageView;
    }

    public boolean validateForm() {
        String senderAddressA = mSenderAddressATextView.getText().toString();
        String senderAddressB = mSenderAddressBTextView.getText().toString();
        String receiverAddressA = mReceiverAddressATextView.getText().toString();
        String receiverAddressB = mReceiverAddressBTextView.getText().toString();
        String receiverName = mReceiverNameTextView.getText().toString();
        String receiverPhone = mReceiverPhoneTextView.getText().toString();

        if (senderAddressA.equals("") || senderAddressB.equals("") || receiverAddressA.equals("") || receiverAddressB.equals("") || receiverName.equals("") || receiverPhone.equals("")) {
            Toast.makeText(getActivity(), "입력하지 않은 항목이 있습니다.", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (!receiverPhone.matches("[0-9]{3}-[0-9]{4}-[0-9]{4}")) {
            Toast.makeText(getActivity(), "수령인 전화번호가 잘못 입력되었습니다.(010-0000-0000 형태)", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }

    public void register() {
        // 등록 버튼 클릭시 서버로 등록 내용 전송
        // 텍스트 데이터를 먼저 전송한 후 이미지 데이터는 따로 전송

        String senderId = SharedPreferenceManager.getInstance(getActivity()).getUserInformation().getUserId();
        int weight = mWeightIndex;
        String senderAddressA = mSenderAddressATextView.getText().toString();
        String senderAddressB = mSenderAddressBTextView.getText().toString();
        String receiverAddressA = mReceiverAddressATextView.getText().toString();
        String receiverAddressB = mReceiverAddressBTextView.getText().toString();
        String receiverName = mReceiverNameTextView.getText().toString();
        String receiverPhone = mReceiverPhoneTextView.getText().toString();
        int distance = 0;
        if (mDistanceTextView.getText().toString().equals("-")) {
            distance = 1000;
        } else {
            distance = (int) (Double.parseDouble(mDistanceTextView.getText().toString().substring(0, mDistanceTextView.getText().toString().length() - 3)) * 1000);
        }
        int price = Integer.parseInt(mPriceTextView.getText().toString().substring(0, mPriceTextView.getText().toString().length() - 2));
        int deadline = mDeadLineIndex;

        if (!validateForm()) {
            return;
        }

        JSONObject body = new JSONObject();
        try {
            body.put("senderId", senderId);
            body.put("weight", weight);
            body.put("senderAddressA", senderAddressA);
            body.put("senderAddressB", senderAddressB);
            body.put("receiverAddressA", receiverAddressA);
            body.put("receiverAddressB", receiverAddressB);
            body.put("receiverName", receiverName);
            body.put("receiverPhone", receiverPhone);
            body.put("distance", distance);
            body.put("price", price);
            body.put("deadline", deadline);
        } catch (JSONException e) {
            Log.e(TAG, Log.getStackTraceString(e));
        }

        // 텍스트 데이터 전송

        HttpRequest request = new HttpRequest(Api.POST_PACKAGE, null, body);

        new Connector(
                new Runnable() {
                    @Override
                    public void run() {
                        enableProgressBar();
                    }
                },
                null,
                new HttpCallback() {
                    @Override
                    public void run(HttpResponse response) {
                        try {
                            if (mImageList.size() == 0) {
                                disableProgressBar();

                                ((NavigationView) getActivity()
                                        .findViewById(R.id.menu))
                                        .getMenu()
                                        .getItem(2)
                                        .setChecked(true);

                                getActivity()
                                        .getSupportFragmentManager()
                                        .beginTransaction()
                                        .replace(R.id.container, new SenderProgressFragment())
                                        .commit();

                                return;
                            }

                            int packageId = response.getResponseBody().getJSONObject("data").getInt("packageId");

                            HashMap<String, String> headers = new HashMap<>();
                            headers.put("Content-Type", "application/octet-stream");

                            HashMap<String, String> params = new HashMap<>();
                            params.put("packageId", String.valueOf(packageId));

                            for (int i = 0; i < mImageList.size(); i++) {
                                final int finalI = i;

                                try {
                                    ContentResolver contentResolver = getActivity().getContentResolver();

                                    headers.put("X-Content-Encoding", MimeTypeMap.getSingleton().getExtensionFromMimeType(contentResolver.getType(mImageList.get(finalI))));
                                    byte[] buffer = new byte[contentResolver.openInputStream(mImageList.get(finalI)).available()];
                                    contentResolver.openInputStream(mImageList.get(finalI)).read(buffer);

                                    // 이미지 데이터 전송 (octet-stream 형식)

                                    HttpRequest request = new HttpRequest(Api.POST_IMAGE, headers, buffer, params);

                                    new Connector(
                                            null,
                                            null,
                                            new HttpCallback() {
                                                @Override
                                                public void run(HttpResponse response) {
                                                    mUploadStatus.set(finalI, Boolean.TRUE);

                                                    for (int j = 0; j < mUploadStatus.size(); j++) {
                                                        if (!mUploadStatus.get(j)) {
                                                            return;
                                                        }
                                                    }

                                                    disableProgressBar();

                                                    ((NavigationView) getActivity()
                                                            .findViewById(R.id.menu))
                                                            .getMenu()
                                                            .getItem(2)
                                                            .setChecked(true);

                                                    getActivity()
                                                            .getSupportFragmentManager()
                                                            .beginTransaction()
                                                            .replace(R.id.container, new SenderProgressFragment())
                                                            .commit();
                                                }
                                            }
                                    ).connect(request);
                                } catch (IOException e) {
                                    Log.e(TAG, Log.getStackTraceString(e));
                                }
                            }
                        } catch (JSONException e) {
                            Log.e(TAG, Log.getStackTraceString(e));
                        }
                    }
                }
        ).connect(request);
    }

    public float parseAddress() throws IOException {
        // 등록된 주소를 위도, 경도로 변환(Android Geocoder 사용) 후 좌표간 거리 계산

        if (MainActivity.geocoder == null) {
            MainActivity.geocoder = new Geocoder(getActivity());
        }

        List<Address> senderAddressList = MainActivity.geocoder.getFromLocationName(mSenderAddressATextView.getText() + " " + mSenderAddressBTextView.getText(), 1);
        List<Address> receiverAddressList = MainActivity.geocoder.getFromLocationName(mReceiverAddressATextView.getText() + " " + mReceiverAddressBTextView.getText(), 1);

        if (senderAddressList.size() == 0 || receiverAddressList.size() == 0) {
            throw new IOException();
        }

        Address senderAddress = senderAddressList.get(0);
        Address receiverAddress = receiverAddressList.get(0);

        Location senderLocation = new Location("sender");
        Location receiverLocation = new Location("receiver");

        senderLocation.setLatitude(senderAddress.getLatitude());
        senderLocation.setLatitude(senderAddress.getLongitude());

        receiverLocation.setLatitude(receiverAddress.getLatitude());
        receiverLocation.setLatitude(receiverAddress.getLongitude());

        return ((float) Math.round(senderLocation.distanceTo(receiverLocation) / 10)) / 100;
    }
}
