package com.sotree.blockchaindelivery.DTO;

import android.os.Parcel;
import android.os.Parcelable;

public class UserDTO implements Parcelable {
    public static final Creator<UserDTO> CREATOR = new Creator<UserDTO>() {
        @Override
        public UserDTO createFromParcel(Parcel in) {
            return new UserDTO(in);
        }

        @Override
        public UserDTO[] newArray(int size) {
            return new UserDTO[size];
        }
    };
    private String mUserId;
    private String mUserPw;
    private String mUserName;
    private String mUserPhone;
    private int mAuthorized;

    public UserDTO(String userId, String userPw, String userName, String userPhone, int authorized) {
        mUserId = userId;
        mUserPw = userPw;
        mUserName = userName;
        mUserPhone = userPhone;
        mAuthorized = authorized;
    }

    public UserDTO(Parcel in) {
        mUserId = in.readString();
        mUserPw = in.readString();
        mUserName = in.readString();
        mUserPhone = in.readString();
        mAuthorized = in.readInt();
    }

    public String getUserId() {
        return mUserId;
    }

    public void setUserId(String userId) {
        mUserId = userId;
    }

    public String getUserPw() {
        return mUserPw;
    }

    public void setUserPw(String userPw) {
        mUserPw = userPw;
    }

    public String getUserName() {
        return mUserName;
    }

    public void setUserName(String userName) {
        mUserName = userName;
    }

    public String getUserPhone() {
        return mUserPhone;
    }

    public void setUserPhone(String userPhone) {
        mUserPhone = userPhone;
    }

    public int getAuthorized() {
        return mAuthorized;
    }

    public void setAuthorized(int authorized) {
        mAuthorized = authorized;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(mUserId);
        parcel.writeString(mUserPw);
        parcel.writeString(mUserName);
        parcel.writeString(mUserPhone);
        parcel.writeInt(mAuthorized);
    }
}
