package com.sotree.blockchaindelivery.Activity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.sotree.blockchaindelivery.R;

import java.text.NumberFormat;
import java.util.Locale;

public class KakaoDemoActivity extends AppCompatActivity {
    private boolean mChecked = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kakao_demo);

        ImageView topButton = findViewById(R.id.imageView);

        TextView price0 = findViewById(R.id.activity_kakao_demo_price0);
        TextView price1 = findViewById(R.id.activity_kakao_demo_price1);

        price0.setText(NumberFormat.getNumberInstance(Locale.US).format(getIntent().getIntExtra("price", 3000)) + "원");
        price1.setText(NumberFormat.getNumberInstance(Locale.US).format(getIntent().getIntExtra("price", 3000)) + "원");

        final ImageView imageView = findViewById(R.id.imageview_checkbox);
        final Button button = findViewById(R.id.button);

        button.setBackgroundColor(Color.rgb(214, 214, 215));
        button.setTextColor(Color.rgb(170, 170, 170));

        topButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.putExtra("result", false);
                setResult(RESULT_OK, intent);
                finish();
                overridePendingTransition(0, 0);
            }
        });

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mChecked) {
                    imageView.setImageResource(R.drawable.pay_unchecked);
                    button.setBackgroundColor(Color.rgb(214, 214, 215));
                    button.setTextColor(Color.rgb(170, 170, 170));
                    mChecked = false;
                } else {
                    imageView.setImageResource(R.drawable.pay_checked);
                    button.setBackgroundColor(Color.rgb(253, 223, 27));
                    button.setTextColor(Color.rgb(0, 0, 0));
                    mChecked = true;
                }
            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mChecked) {
                    Intent intent = new Intent();
                    intent.putExtra("result", true);
                    setResult(RESULT_OK, intent);
                    finish();
                    overridePendingTransition(0, 0);
                }
            }
        });
    }
}
