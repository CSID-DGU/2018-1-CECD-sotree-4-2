package com.sotree.blockchaindelivery.ListView.Adapter;

import android.content.Context;
import android.location.Location;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.sotree.blockchaindelivery.DTO.PackageDTO;
import com.sotree.blockchaindelivery.ListView.Holder.PackageListViewHolder;
import com.sotree.blockchaindelivery.R;
import com.sotree.blockchaindelivery.SharedPreferenceManager;
import com.sotree.blockchaindelivery.Util;

public class PackageListViewAdapter extends ListViewAdapter<PackageDTO> {
    private static final String TAG = "PackageListViewAdapter";

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        PackageDTO item = getItem(position);
        PackageListViewHolder holder = null;

        SharedPreferenceManager sharedPreferenceManager = SharedPreferenceManager.getInstance(parent.getContext());

        if (convertView == null) {
            convertView = ((LayoutInflater) parent.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.item_package_progress, parent, false);

            holder = new PackageListViewHolder(convertView);

            convertView.setTag(holder);
        } else {
            holder = (PackageListViewHolder) convertView.getTag();
        }

        Location current = new Location("current");

        if (!sharedPreferenceManager.getCurrentPosition().equals("")) {
            current.setLatitude(Float.parseFloat(sharedPreferenceManager.getCurrentPosition().split(" ")[0]));
            current.setLongitude(Float.parseFloat(sharedPreferenceManager.getCurrentPosition().split(" ")[1]));
        } else {
            current.setLatitude(0);
            current.setLongitude(0);
        }

        //        holder.getPackageIdTextView().setText(p.getPackageId() + "");
        switch (item.getStatus()) {
            case 0:
            case 1:
                holder.getFromTextView().setText("출발지까지");
                holder.getSenderDistanceTextView().setText(((float) (Math.round(current.distanceTo(item.getSenderLocation()) / 10))) / 100 + "km");
                break;
            case 2:
                holder.getFromTextView().setText("도착지까지");
                holder.getSenderDistanceTextView().setText(((float) Math.round(current.distanceTo(item.getReceiverLocation()) / 10)) / 100 + "km");
                break;
            case 3:
                //                holder.getSenderDistanceTextView().setText("배송 완료를 승인하세요!");
            default:
                break;
        }

        holder.getPriceTextView().setText(String.valueOf(item.getPrice()));
        holder.getSenderAddressTextView().setText(item.getSenderAddressA());
        holder.getReceiverAddressTextView().setText(item.getReceiverAddressA());
        holder.getDeadLineTextView().setText(Util.DEADLINE_ARRAY[item.getDeadline()] + " 이내");
        holder.getWeightTextView().setText(Util.WEIGHT_ARRAY[item.getWeight()]);
        holder.getStatusTextView().setText(Util.STATUS_ARRAY[item.getStatus()]);

        return convertView;
    }
}
