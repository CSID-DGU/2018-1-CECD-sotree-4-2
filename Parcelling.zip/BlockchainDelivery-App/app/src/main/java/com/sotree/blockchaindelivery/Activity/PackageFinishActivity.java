package com.sotree.blockchaindelivery.Activity;

import android.content.DialogInterface;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.sotree.blockchaindelivery.Connection.Api;
import com.sotree.blockchaindelivery.Connection.Connector;
import com.sotree.blockchaindelivery.Connection.DTO.HttpRequest;
import com.sotree.blockchaindelivery.Connection.DTO.HttpResponse;
import com.sotree.blockchaindelivery.Connection.HttpCallback;
import com.sotree.blockchaindelivery.DTO.PackageDTO;
import com.sotree.blockchaindelivery.R;
import com.sotree.blockchaindelivery.SharedPreferenceManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.HashMap;

public class PackageFinishActivity extends AppCompatActivity implements View.OnClickListener {
    private static final String TAG = "PackageFinish";

    PackageDTO mPackageDTO;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_package_finish);

        TextView senderNameTextView = findViewById(R.id.activity_package_finish_tv_sender_name);
        TextView senderAddressATextView = findViewById(R.id.activity_package_finish_tv_sender_address_a);
        TextView senderAddressBTextView = findViewById(R.id.activity_package_finish_tv_sender_address_b);
        TextView currentDistanceTextView = findViewById(R.id.activity_package_finish_tv_current_distance);
        TextView receiverAddressATextView = findViewById(R.id.activity_package_finish_tv_receiver_address_a);
        TextView receiverAddressBTextView = findViewById(R.id.activity_package_finish_tv_receiver_address_b);
        TextView priceTextView = findViewById(R.id.activity_package_finish_tv_price);
        TextView distanceTextView = findViewById(R.id.activity_package_finish_tv_distance);
        Button acceptButton = findViewById(R.id.activity_package_finish_btn_finish);

        mPackageDTO = getIntent().getParcelableExtra("package");

        senderNameTextView.setText(mPackageDTO.getSenderId() + " 님의 택배");
        senderAddressATextView.setText(mPackageDTO.getSenderAddressA());
        senderAddressBTextView.setText(mPackageDTO.getSenderAddressB());
        currentDistanceTextView.setText("현재 위치로부터 0.00km");
        receiverAddressATextView.setText(mPackageDTO.getReceiverAddressA());
        receiverAddressBTextView.setText(mPackageDTO.getReceiverAddressB());
        priceTextView.setText("금액: " + mPackageDTO.getPrice() + "원");
        distanceTextView.setText("총 거리: " + String.valueOf(mPackageDTO.getDistance() * 1.0 / 1000) + " km");

        acceptButton.setOnClickListener(this);

        Geocoder geocoder = new Geocoder(PackageFinishActivity.this);

        Address senderAddress = null;

        Location senderLocation = new Location("sender");

        Location currentLocation = new Location("current");
        currentLocation.setLatitude(Float.parseFloat(SharedPreferenceManager.getInstance(PackageFinishActivity.this).getCurrentPosition().split(" ")[0]));
        currentLocation.setLongitude(Float.parseFloat(SharedPreferenceManager.getInstance(PackageFinishActivity.this).getCurrentPosition().split(" ")[1]));

        try {
            senderAddress = geocoder.getFromLocationName(mPackageDTO.getSenderAddressA() + " " + mPackageDTO.getSenderAddressB(), 1).get(0);
        } catch (IOException e) {
            Log.e(TAG, Log.getStackTraceString(e));
        }

        if (senderAddress != null) {
            senderLocation.setLatitude(senderAddress.getLatitude());
            senderLocation.setLongitude(senderAddress.getLongitude());
        }

        currentDistanceTextView.setText("현재 위치로부터 " + ((float) Math.round(currentLocation.distanceTo(senderLocation) / 10)) / 100 + "km");
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.activity_package_finish_btn_finish:
                new AlertDialog.Builder(PackageFinishActivity.this).setTitle("택배 선택 확인").setMessage("선택한 택배의 배송이 완료되었습니까?").setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        HashMap<String, String> params = new HashMap<>();
                        params.put("deliveryId", String.valueOf(mPackageDTO.getDeliveryId()));

                        JSONObject body = new JSONObject();

                        try {
                            body.put("status", 3);
                        } catch (JSONException e) {
                            Log.e(TAG, Log.getStackTraceString(e));
                        }

                        HttpRequest request = new HttpRequest(Api.PATCH_DELIVERY, null, body, params);

                        new Connector(
                                null,
                                null,
                                new HttpCallback() {
                                    @Override
                                    public void run(HttpResponse response) {
                                        switch (response.getStatusCode()) {
                                            case 204:
                                                Toast.makeText(PackageFinishActivity.this, "완료되었습니다. 수신자의 확인 대기중입니다.", Toast.LENGTH_SHORT).show();
                                                finish();
                                                overridePendingTransition(0, 0);
                                                break;
                                            case 500:
                                                Toast.makeText(PackageFinishActivity.this, "서버 오류입니다.", Toast.LENGTH_SHORT).show();
                                                break;
                                        }
                                    }
                                }
                        ).connect(request);
                    }
                }).setNegativeButton("취소", null).show();
                break;
        }
    }
}
