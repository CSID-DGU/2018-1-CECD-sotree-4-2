package com.sotree.blockchaindelivery;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.sotree.blockchaindelivery.DTO.UserDTO;

public class SharedPreferenceManager {
    // 내부 SharedPreference 에 저장해주는 유틸

    private static SharedPreferenceManager mInstance;

    private SharedPreferences mPreferences;

    private SharedPreferenceManager(Context context) {
        mPreferences = PreferenceManager.getDefaultSharedPreferences(context);
    }

    public static SharedPreferenceManager getInstance(Context context) {
        if (mInstance == null) {
            mInstance = new SharedPreferenceManager(context);
        }

        return mInstance;
    }

    public void login(UserDTO userDTO) {
        SharedPreferences.Editor editor = mPreferences.edit();

        editor.putString("userId", userDTO.getUserId());
        editor.putString("userPw", userDTO.getUserPw());
        editor.putString("userName", userDTO.getUserName());
        editor.putString("userPhone", userDTO.getUserPhone());
        editor.putInt("authorized", userDTO.getAuthorized());

        editor.apply();
    }

    public void logout() {
        SharedPreferences.Editor editor = mPreferences.edit();

        editor.putString("userId", "");
        editor.putString("userPw", "");
        editor.putString("userName", "");
        editor.putString("userPhone", "");
        editor.putInt("authorized", 0);
        editor.putString("role", "");

        editor.apply();
    }

    public UserDTO getUserInformation() {
        return new UserDTO(mPreferences.getString("userId", ""), mPreferences.getString("userPw", ""), mPreferences.getString("userName", ""), mPreferences.getString("userPhone", ""), mPreferences.getInt("authorized", 0));
    }

    public String getRole() {
        return mPreferences.getString("role", "");
    }

    public void setRole(String role) {
        mPreferences.edit().putString("role", role).apply();
    }

    public String getCurrentPosition() {
        return mPreferences.getString("currentPosition", "");
    }

    public void setCurrentPosition(String currentPosition) {
        mPreferences.edit().putString("currentPosition", currentPosition).apply();
    }
}
