package com.sotree.blockchaindelivery;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.util.Log;

import com.sotree.blockchaindelivery.Connection.Api;
import com.sotree.blockchaindelivery.Connection.Connector;
import com.sotree.blockchaindelivery.Connection.DTO.HttpRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class GPSBroadcastReceiver extends BroadcastReceiver {
    // 백그라운드에서 GPS 값을 받고 서버에 전송하는 서비스

    private static final String TAG = "GPSBroadcastReceiver";

    private LocationManager mLocationmanager;
    private SharedPreferenceManager mSharedPreferenceManager;

    private final LocationListener mLocationListener = new LocationListener() {
        public void onLocationChanged(Location location) {
            // 위치 값이 등록되었을 때 아이디와 함께 서버로 전송 (현재 위치로 재등록)

            String driverId = mSharedPreferenceManager.getUserInformation().getUserId();
            double latitude = location.getLatitude();
            double longitude = location.getLongitude();

            mSharedPreferenceManager.setCurrentPosition(latitude + " " + longitude);

            // 로그아웃 상태면 보내지 않음
            if (driverId.equals("")) {
                return;
            }

            HashMap<String, String> params = new HashMap<>();
            params.put("driverId", driverId);

            JSONObject body = new JSONObject();

            try {
                body.put("latitude", latitude);
                body.put("longitude", longitude);
            } catch (JSONException e) {
                Log.e(TAG, Log.getStackTraceString(e));
            }

            HttpRequest request = new HttpRequest(Api.PATCH_POSITION, null, body, params);

            new Connector(null, null, null).connect(request);

            mLocationmanager.removeUpdates(mLocationListener);
        }

        public void onProviderDisabled(String provider) {
        }

        public void onProviderEnabled(String provider) {
        }

        public void onStatusChanged(String provider, int status, Bundle extras) {
        }

    };

    @Override
    public void onReceive(Context context, Intent intent) {
        mSharedPreferenceManager = SharedPreferenceManager.getInstance(context);

        mLocationmanager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);

        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        mLocationmanager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1000, 1, mLocationListener);
        mLocationmanager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 1, mLocationListener);
    }
}
