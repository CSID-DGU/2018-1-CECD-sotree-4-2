package com.sotree.blockchaindelivery.Fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.sotree.blockchaindelivery.R;

public class SenderMainFragment extends Fragment implements View.OnClickListener {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_sender_main, container, false);

        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("발송자 메뉴");

        Button registerPackageButton = rootView.findViewById(R.id.activity_sender_btn_register);
        Button progressPackageButton = rootView.findViewById(R.id.activity_sender_btn_progress);
        Button completePackageButton = rootView.findViewById(R.id.activity_sender_btn_complete);

        registerPackageButton.setOnClickListener(this);
        progressPackageButton.setOnClickListener(this);
        completePackageButton.setOnClickListener(this);

        return rootView;
    }

    @Override
    public void onClick(View v) {
        // 버튼 선택에 따라 화면 이동

        switch (v.getId()) {
            case R.id.activity_sender_btn_register:
                ((NavigationView) getActivity()
                        .findViewById(R.id.menu))
                        .getMenu()
                        .getItem(1)
                        .setChecked(true);

                getActivity()
                        .getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.container, new SenderRegisterFragment())
                        .commit();
                break;
            case R.id.activity_sender_btn_progress:
                ((NavigationView) getActivity()
                        .findViewById(R.id.menu))
                        .getMenu()
                        .getItem(2)
                        .setChecked(true);

                getActivity()
                        .getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.container, new DriverProgressFragment())
                        .commit();
                break;
            case R.id.activity_sender_btn_complete:
                ((NavigationView) getActivity()
                        .findViewById(R.id.menu))
                        .getMenu()
                        .getItem(3)
                        .setChecked(true);

                getActivity()
                        .getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.container, new SenderFinishedFragment())
                        .commit();
                break;
            default:
                break;
        }
    }
}
