package com.sotree.blockchaindelivery.Activity;

import android.content.DialogInterface;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.sotree.blockchaindelivery.Connection.Api;
import com.sotree.blockchaindelivery.Connection.Connector;
import com.sotree.blockchaindelivery.Connection.DTO.HttpRequest;
import com.sotree.blockchaindelivery.Connection.DTO.HttpResponse;
import com.sotree.blockchaindelivery.Connection.HttpCallback;
import com.sotree.blockchaindelivery.DTO.PackageDTO;
import com.sotree.blockchaindelivery.R;
import com.sotree.blockchaindelivery.SharedPreferenceManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

public class DriverAcceptPackageActivity extends AppCompatActivity implements View.OnClickListener {
    private static final String TAG = "DriverAcceptPackage";

    PackageDTO mPackageDTO;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_accept_package);

        TextView senderNameTextView = findViewById(R.id.activity_driver_accept_tv_sender_name);
        TextView senderAddressATextView = findViewById(R.id.activity_driver_accept_tv_sender_address_a);
        TextView senderAddressBTextView = findViewById(R.id.activity_driver_accept_tv_sender_address_b);
        TextView currentDistanceTextView = findViewById(R.id.activity_driver_accept_tv_current_distance);
        TextView receiverAddressATextView = findViewById(R.id.activity_driver_accept_tv_receiver_address_a);
        TextView receiverAddressBTextView = findViewById(R.id.activity_driver_accept_tv_receiver_address_b);
        TextView priceTextView = findViewById(R.id.activity_driver_accept_tv_price);
        TextView distanceTextView = findViewById(R.id.activity_driver_accept_tv_distance);
        Button acceptButton = findViewById(R.id.activity_driver_accept_btn_accept);

        mPackageDTO = getIntent().getParcelableExtra("package");

        senderNameTextView.setText(mPackageDTO.getSenderId());
        senderAddressATextView.setText(mPackageDTO.getSenderAddressA());
        senderAddressBTextView.setText(mPackageDTO.getSenderAddressB());
        currentDistanceTextView.setText("0.00km");
        receiverAddressATextView.setText(mPackageDTO.getReceiverAddressA());
        receiverAddressBTextView.setText(mPackageDTO.getReceiverAddressB());
        priceTextView.setText(mPackageDTO.getPrice() + "원");
        distanceTextView.setText(String.valueOf(mPackageDTO.getDistance() * 1.0 / 1000) + "km");

        acceptButton.setOnClickListener(this);

        Geocoder geocoder = new Geocoder(DriverAcceptPackageActivity.this);

        Address senderAddress = null;

        Location senderLocation = new Location("sender");

        Location currentLocation = new Location("current");
        currentLocation.setLatitude(Float.parseFloat(SharedPreferenceManager.getInstance(DriverAcceptPackageActivity.this).getCurrentPosition().split(" ")[0]));
        currentLocation.setLongitude(Float.parseFloat(SharedPreferenceManager.getInstance(DriverAcceptPackageActivity.this).getCurrentPosition().split(" ")[1]));

        try {
            senderAddress = geocoder.getFromLocationName(mPackageDTO.getSenderAddressA() + " " + mPackageDTO.getSenderAddressB(), 1).get(0);
        } catch (IOException e) {
            Log.e(TAG, Log.getStackTraceString(e));
        }

        if (senderAddress != null) {
            senderLocation.setLatitude(senderAddress.getLatitude());
            senderLocation.setLongitude(senderAddress.getLongitude());
        }

        currentDistanceTextView.setText(((float) Math.round(currentLocation.distanceTo(senderLocation) / 10)) / 100 + "km");
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.activity_driver_accept_btn_accept:
                new AlertDialog.Builder(DriverAcceptPackageActivity.this).setTitle("택배 선택 확인").setMessage("선택한 택배를 배송하시겠습니까?").setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        JSONObject body = new JSONObject();

                        try {
                            body.put("packageId", mPackageDTO.getPackageId());
                            body.put("userId", SharedPreferenceManager.getInstance(DriverAcceptPackageActivity.this).getUserInformation().getUserId());
                        } catch (JSONException e) {
                            Log.e(TAG, Log.getStackTraceString(e));
                        }

                        HttpRequest request = new HttpRequest(Api.POST_DELIVERY, null, body);

                        new Connector(
                                null,
                                null,
                                new HttpCallback() {
                                    @Override
                                    public void run(HttpResponse response) {
                                        switch (response.getStatusCode()) {
                                            case 201:
                                                setResult(1);
                                                finish();
                                                overridePendingTransition(0, 0);
                                                break;
                                            case 500:
                                                Toast.makeText(DriverAcceptPackageActivity.this, "서버 오류입니다.", Toast.LENGTH_SHORT).show();
                                                break;
                                        }
                                    }
                                }
                        ).connect(request);
                    }
                }).setNegativeButton("취소", null).show();

                break;
        }
    }
}
