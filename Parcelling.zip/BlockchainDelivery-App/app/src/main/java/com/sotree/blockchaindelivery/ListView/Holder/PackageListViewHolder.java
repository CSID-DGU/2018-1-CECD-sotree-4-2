package com.sotree.blockchaindelivery.ListView.Holder;

import android.view.View;
import android.widget.TextView;

import com.sotree.blockchaindelivery.R;

public class PackageListViewHolder {
    private TextView mPackageIdTextView;
    private TextView mFromTextView;
    private TextView mSenderDistanceTextView;
    private TextView mPriceTextView;
    private TextView mSenderAddressTextView;
    private TextView mReceiverAddressTextView;
    private TextView mWeightTextView;
    private TextView mDeadLineTextView;
    private TextView mStatusTextView;

    public PackageListViewHolder(View itemView) {
        mPackageIdTextView = itemView.findViewById(R.id.item_package_progress_tv_package_id);
        mFromTextView = itemView.findViewById(R.id.item_package_progress_tv_from);
        mSenderDistanceTextView = itemView.findViewById(R.id.item_package_progress_tv_sender_distance);
        mPriceTextView = itemView.findViewById(R.id.item_package_progress_tv_price);
        mSenderAddressTextView = itemView.findViewById(R.id.item_package_progress_tv_sender_address);
        mReceiverAddressTextView = itemView.findViewById(R.id.item_package_progress_tv_receiver_address);
        mWeightTextView = itemView.findViewById(R.id.item_package_progress_tv_weight);
        mDeadLineTextView = itemView.findViewById(R.id.item_package_progress_tv_deadline);
        mStatusTextView = itemView.findViewById(R.id.item_package_progress_tv_status);
    }

    public TextView getSenderDistanceTextView() {
        return mSenderDistanceTextView;
    }

    public TextView getPriceTextView() {
        return mPriceTextView;
    }

    public TextView getSenderAddressTextView() {
        return mSenderAddressTextView;
    }

    public TextView getReceiverAddressTextView() {
        return mReceiverAddressTextView;
    }

    public TextView getWeightTextView() {
        return mWeightTextView;
    }

    public TextView getDeadLineTextView() {
        return mDeadLineTextView;
    }

    public TextView getPackageIdTextView() {
        return mPackageIdTextView;
    }

    public TextView getStatusTextView() {
        return mStatusTextView;
    }

    public TextView getFromTextView() {
        return mFromTextView;
    }
}
