package com.sotree.blockchaindelivery;

public class Util {
    // 택배 데이터 인덱스-실제값 매치

    public static final String[] STATUS_ARRAY = {"대기중", "인계중", "배송중", "승인 대기중", "배송 완료"};
    public static final String[] WEIGHT_ARRAY = {"2kg 이하", "5kg 이하", "10kg 이하", "20kg 이하", "30kg 이하"};
    public static final String[] DEADLINE_ARRAY = {"3시간", "6시간", "9시간", "12시간", "15시간", "18시간", "21시간", "24시간"};
}
