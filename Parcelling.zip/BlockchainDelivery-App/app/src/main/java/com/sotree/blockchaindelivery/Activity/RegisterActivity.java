package com.sotree.blockchaindelivery.Activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.sotree.blockchaindelivery.Connection.Api;
import com.sotree.blockchaindelivery.Connection.Connector;
import com.sotree.blockchaindelivery.Connection.DTO.HttpRequest;
import com.sotree.blockchaindelivery.Connection.DTO.HttpResponse;
import com.sotree.blockchaindelivery.Connection.HttpCallback;
import com.sotree.blockchaindelivery.R;

import org.json.JSONException;
import org.json.JSONObject;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener {
    // 가입 화면

    private static final String TAG = "Register";

    private ProgressBar mProgressBar;

    private EditText mUserIdEditText;
    private EditText mUserPwEditText;
    private EditText mUserPwVerifyEditText;
    private EditText mNameEditText;
    private EditText mPhoneEditText;
    private EditText mDefaultAddressAEditText;
    private EditText mDefaultAddressBEditText;

    private Button mRegisterButton;
    private Button mCancelButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mProgressBar = findViewById(R.id.progressbar);

        mUserIdEditText = findViewById(R.id.activity_register_et_user_id);
        mUserPwEditText = findViewById(R.id.activity_register_et_user_pw);
        mUserPwVerifyEditText = findViewById(R.id.activity_register_et_user_pw_verify);
        mNameEditText = findViewById(R.id.activity_register_et_name);
        mPhoneEditText = findViewById(R.id.activity_register_et_phone);

        mDefaultAddressAEditText = findViewById(R.id.activity_register_et_default_address_a);
        mDefaultAddressBEditText = findViewById(R.id.activity_register_et_default_address_b);

        mRegisterButton = findViewById(R.id.activity_register_btn_register);
        mCancelButton = findViewById(R.id.activity_register_btn_cancel);

        mRegisterButton.setOnClickListener(this);
        mCancelButton.setOnClickListener(this);
    }

    private void register() {
        // 가입 버튼 클릭시 가입

        if (!validateForm()) {
            Toast.makeText(RegisterActivity.this, "입력란을 바르게 입력하세요.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!mUserPwEditText.getText().toString().equals(mUserPwVerifyEditText.getText().toString())) {
            Toast.makeText(this, "비밀번호와 확인란이 일치하지 않습니다..", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!mPhoneEditText.getText().toString().matches("[0-9]{3}-[0-9]{4}-[0-9]{4}")) {
            Toast.makeText(this, "전화번호가 잘못 입력되었습니다.(010-0000-0000 형태)", Toast.LENGTH_SHORT).show();
            return;
        }

        JSONObject body = new JSONObject();

        try {
            body.put("userId", mUserIdEditText.getText().toString());
            body.put("userPw", mUserPwEditText.getText().toString());
            body.put("userName", mNameEditText.getText().toString());
            body.put("userPhone", mPhoneEditText.getText().toString());
            body.put("defaultAddressA", mDefaultAddressAEditText.getText().toString());
            body.put("defaultAddressB", mDefaultAddressBEditText.getText().toString());
        } catch (JSONException e) {
            Log.e(TAG, Log.getStackTraceString(e));
        }

        // 가입에 필요한 데이터를 JSON 객체에 담아 서버로 전송

        HttpRequest request = new HttpRequest(Api.REGISTER, null, body);

        new Connector(
                new Runnable() {
                    @Override
                    public void run() {
                        startProgress();
                    }
                },
                null,
                new HttpCallback() {
                    @Override
                    public void run(HttpResponse response) {
                        // 서버 HTTP 응답에 따라 토스트 알림 결정
                        switch (response.getStatusCode()) {
                            case 201:
                                Toast.makeText(RegisterActivity.this, "회원가입되었습니다.", Toast.LENGTH_SHORT).show();
                                finish();
                                overridePendingTransition(0, 0);
                                break;
                            case 409:
                                Toast.makeText(RegisterActivity.this, "중복된 아이디입니다.", Toast.LENGTH_SHORT).show();
                                stopProgress();
                                break;
                            case 500:
                                Toast.makeText(RegisterActivity.this, "서버 오류입니다.", Toast.LENGTH_SHORT).show();
                                stopProgress();
                                break;
                        }
                    }
                }
        ).connect(request);
    }

    private boolean validateForm() {
        return !mUserIdEditText.getText().toString().equals("") && !mUserPwEditText.getText().toString().equals("") && !mUserPwVerifyEditText.getText().toString().equals("") && !mNameEditText.getText().toString().equals("") && !mPhoneEditText.getText().toString().equals("") && !mDefaultAddressAEditText.getText().toString().equals("") && !mDefaultAddressBEditText.getText().toString().equals("");
    }

    private void startProgress() {
        // 프로그레스 바 시작

        mProgressBar.setVisibility(View.VISIBLE);

        mUserIdEditText.setEnabled(false);
        mUserPwEditText.setEnabled(false);
        mNameEditText.setEnabled(false);
        mPhoneEditText.setEnabled(false);

        mRegisterButton.setEnabled(false);
        mCancelButton.setEnabled(false);
    }

    private void stopProgress() {
        // 프로그레스 바 종료

        mProgressBar.setVisibility(View.INVISIBLE);

        mUserIdEditText.setEnabled(true);
        mUserPwEditText.setEnabled(true);
        mNameEditText.setEnabled(true);
        mPhoneEditText.setEnabled(true);

        mRegisterButton.setEnabled(true);
        mCancelButton.setEnabled(true);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.activity_register_btn_register:
                register();
                break;
            case R.id.activity_register_btn_cancel:
                finish();
                overridePendingTransition(0, 0);
                break;
        }
    }
}
