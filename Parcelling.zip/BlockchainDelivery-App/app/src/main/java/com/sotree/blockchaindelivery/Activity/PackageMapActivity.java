package com.sotree.blockchaindelivery.Activity;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.sotree.blockchaindelivery.DTO.PackageDTO;
import com.sotree.blockchaindelivery.R;
import com.sotree.blockchaindelivery.Util;

import java.io.IOException;

public class PackageMapActivity extends AppCompatActivity implements OnMapReadyCallback {
    // 택배의 현재 위치를 지도로 표시하는 화면

    // Google Map API 사용

    private static final String TAG = "PackageMap";

    private PackageDTO mPackageDTO;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_package_map);

        mPackageDTO = getIntent().getParcelableExtra("package");

        TextView statusTextView = findViewById(R.id.activity_package_map_tv_status);

        statusTextView.setText("택배는 현재 '" + Util.STATUS_ARRAY[mPackageDTO.getStatus()] + "' 상태입니다.");

        MapFragment mapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.activity_package_map_fragment_map);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        // 구글 맵이 준비되면 택배의 현재 주소(위도, 경도)로 지도의 카메라를 이동함

        LatLng packageAddress = new LatLng(Float.parseFloat(mPackageDTO.getCurrentPosition().split(" ")[0]), Float.parseFloat(mPackageDTO.getCurrentPosition().split(" ")[1]));

        CameraPosition position = new CameraPosition.Builder().target(packageAddress).zoom(13).build();

        googleMap.moveCamera(CameraUpdateFactory.newCameraPosition(position));
        //        googleMap.animateCamera(CameraUpdateFactory.zoomTo(13));

        MarkerOptions marker = new MarkerOptions();

        marker.position(packageAddress).title("드라이버 위치");

        try {
            marker.snippet(MainActivity.geocoder.getFromLocation(packageAddress.latitude, packageAddress.longitude, 1).get(0).getAddressLine(0));
        } catch (IOException e) {
            Log.e(TAG, Log.getStackTraceString(e));
        }

        googleMap.addMarker(marker).showInfoWindow();
    }
}
