package com.sotree.blockchaindelivery.Connection;

import android.os.AsyncTask;
import android.util.Log;

import com.sotree.blockchaindelivery.BuildConfig;
import com.sotree.blockchaindelivery.Connection.DTO.HttpRequest;
import com.sotree.blockchaindelivery.Connection.DTO.HttpResponse;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;

public class Connector extends AsyncTask<HttpRequest, Void, HttpResponse> {
    // 서버 연결부

    private static final String TAG = "Connector";

    private Runnable mOnPreExecute;
    private HttpCallback mOnExecute;
    private HttpCallback mOnPostExecute;

    public Connector(Runnable onPreExecute, HttpCallback onExecute, HttpCallback onPostExecute) {
        mOnPreExecute = onPreExecute;
        mOnExecute = onExecute;
        mOnPostExecute = onPostExecute;
    }

    @Override
    protected void onPreExecute() {
        if (mOnPreExecute != null) {
            mOnPreExecute.run();
        }
    }

    @Override
    protected HttpResponse doInBackground(HttpRequest... httpRequests) {
        // http 연결 수립과 헤더, 바디 전송 및 반환값 기록

        HttpRequest request = httpRequests[0];
        HttpResponse response = new HttpResponse(500, new JSONObject());
        HttpURLConnection connection = null;

        try {
            int responseCode = 500;
            String responseBody = "{}";

            connection = (HttpURLConnection) new URL(BuildConfig.host_url + request.getUrl()).openConnection();
            connection.setRequestMethod(request.getApi().getMethod());
            connection.setConnectTimeout(10000);
            connection.setUseCaches(false);
            connection.setDoInput(true);
            connection.setUseCaches(false);
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("Content-Type", "application/json");

            Map<String, String> header = httpRequests[0].getHeader();

            if (header != null) {
                for (String key : header.keySet()) {
                    connection.setRequestProperty(key, header.get(key));
                }
            }

            if (request.getApi().getMethod().equals("POST") || request.getApi().getMethod().equals("PATCH")) {
                connection.setDoOutput(true);

                if (connection.getRequestProperty("Content-Type").equals("application/json")) {
                    connection.getOutputStream().write(request.getBody().toString().getBytes("UTF-8"));
                } else {
                    connection.getOutputStream().write((byte[]) request.getBody());
                }
            }

            responseCode = connection.getResponseCode();

            if (responseCode == HttpURLConnection.HTTP_OK || responseCode == HttpURLConnection.HTTP_CREATED) {
                responseBody = "";

                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
                String line = bufferedReader.readLine();

                while (line != null) {
                    responseBody += line;
                    line = bufferedReader.readLine();
                }

                bufferedReader.close();
                try {
                    new JSONObject(responseBody);
                } catch (JSONException e) {
                    responseBody = "{}";
                }
            }

            response = new HttpResponse(responseCode, new JSONObject(responseBody));
        } catch (IOException | JSONException e) {
            Log.e(TAG, Log.getStackTraceString(e));
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }

        Log.d(TAG + " Request ", httpRequests[0].toString());
        Log.d(TAG + " Response ", response.toString());

        if (mOnExecute != null) {
            mOnExecute.run(response);
        }

        return response;
    }

    @Override
    protected void onPostExecute(HttpResponse httpResponse) {
        if (mOnPostExecute != null) {
            mOnPostExecute.run(httpResponse);
        }
    }

    public AsyncTask<HttpRequest, Void, HttpResponse> connect(HttpRequest... requests) {
        return execute(requests);
    }
}
