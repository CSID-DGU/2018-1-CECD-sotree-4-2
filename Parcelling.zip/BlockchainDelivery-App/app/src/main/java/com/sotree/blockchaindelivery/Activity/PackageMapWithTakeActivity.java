package com.sotree.blockchaindelivery.Activity;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.sotree.blockchaindelivery.Connection.Api;
import com.sotree.blockchaindelivery.Connection.Connector;
import com.sotree.blockchaindelivery.Connection.DTO.HttpRequest;
import com.sotree.blockchaindelivery.Connection.DTO.HttpResponse;
import com.sotree.blockchaindelivery.Connection.HttpCallback;
import com.sotree.blockchaindelivery.DTO.PackageDTO;
import com.sotree.blockchaindelivery.R;
import com.sotree.blockchaindelivery.Util;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.HashMap;

public class PackageMapWithTakeActivity extends AppCompatActivity implements OnMapReadyCallback, View.OnClickListener {
    // 택배의 현재 위치를 지도로 표시하는 화면

    // Google Map API 사용

    private static final String TAG = "PackageMap";

    private PackageDTO mPackageDTO;

    private ProgressDialog mProgressDialog;

    private Button mAcceptTakeButton;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_package_map_with_take);

        mPackageDTO = getIntent().getParcelableExtra("package");

        TextView statusTextView = findViewById(R.id.activity_package_map_with_take_tv_status);

        statusTextView.setText("택배는 현재 '" + Util.STATUS_ARRAY[mPackageDTO.getStatus()] + "' 상태입니다.");

        if (mPackageDTO.getStatus() == 1 || mPackageDTO.getStatus() == 2) {
            MapFragment mapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.activity_package_map_with_take_fragment_map);
            mapFragment.getMapAsync(this);
        } else {
            findViewById(R.id.activity_package_map_with_take_map_container).setVisibility(View.GONE);
        }

        mProgressDialog = new ProgressDialog(PackageMapWithTakeActivity.this);
        mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        mProgressDialog.setMessage("로드 중...");
        mProgressDialog.setCancelable(false);

        mAcceptTakeButton = findViewById(R.id.activity_package_map_with_take_btn_accept_take);
        mAcceptTakeButton.setOnClickListener(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        // 구글 맵이 준비되면 택배의 현재 주소(위도, 경도)로 지도의 카메라를 이동함

        LatLng packageAddress = new LatLng(Float.parseFloat(mPackageDTO.getCurrentPosition().split(" ")[0]), Float.parseFloat(mPackageDTO.getCurrentPosition().split(" ")[1]));

        CameraPosition position = new CameraPosition.Builder().target(packageAddress).zoom(13).build();

        googleMap.moveCamera(CameraUpdateFactory.newCameraPosition(position));
        //        googleMap.animateCamera(CameraUpdateFactory.zoomTo(13));

        MarkerOptions marker = new MarkerOptions();

        switch (mPackageDTO.getStatus()) {
            // 택배 상태에 따라 드라이버 위치/택배 위치 마커 생성
            case 1:
                marker.position(packageAddress).title("드라이버 위치");
                break;
            case 2:
                marker.position(packageAddress).title("택배 위치");
                break;
        }

        try {
            marker.snippet(MainActivity.geocoder.getFromLocation(packageAddress.latitude, packageAddress.longitude, 1).get(0).getAddressLine(0));
        } catch (IOException e) {
            Log.e(TAG, Log.getStackTraceString(e));
        }

        googleMap.addMarker(marker).showInfoWindow();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.activity_package_map_with_take_btn_accept_take:
                new android.support.v7.app.AlertDialog.Builder(PackageMapWithTakeActivity.this).setTitle("택배 인계 확인").setMessage("드라이버에게 택배를 인계하셨습니까?").setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        mProgressDialog.show();
                        HashMap<String, String> params = new HashMap<>();
                        params.put("deliveryId", String.valueOf(mPackageDTO.getDeliveryId()));

                        JSONObject body = new JSONObject();

                        try {
                            body.put("status", 2);
                        } catch (JSONException e) {
                            Log.e(TAG, Log.getStackTraceString(e));
                        }

                        HttpRequest request = new HttpRequest(Api.PATCH_DELIVERY, null, body, params);

                        new Connector(
                                null,
                                null,
                                new HttpCallback() {
                                    @Override
                                    public void run(HttpResponse response) {
                                        mProgressDialog.cancel();
                                        switch (response.getStatusCode()) {
                                            case 204:
                                                Toast.makeText(PackageMapWithTakeActivity.this, "인계 완료되었습니다. 배송이 시작되었습니다.", Toast.LENGTH_SHORT).show();
                                                finish();
                                                overridePendingTransition(0, 0);
                                                break;
                                            case 500:
                                                Toast.makeText(PackageMapWithTakeActivity.this, "서버 오류입니다.", Toast.LENGTH_SHORT).show();
                                                break;
                                        }
                                    }
                                }
                        ).connect(request);
                    }
                }).setNegativeButton("취소", null).show();
                break;
        }
    }
}
