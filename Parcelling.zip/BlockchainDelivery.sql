-- MySQL dump 10.16  Distrib 10.1.34-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: BlockchainDelivery
-- ------------------------------------------------------
-- Server version	10.1.34-MariaDB-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

CREATE DATABASE IF NOT EXISTS `BlockchainDelivery`;
USE `BlockchainDelivery`;

--
-- Table structure for table `Delivery`
--

DROP TABLE IF EXISTS `Delivery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Delivery` (
  `DeliveryId` int(11) NOT NULL AUTO_INCREMENT,
  `PackageId` int(11) NOT NULL,
  `DriverId` varchar(45) NOT NULL,
  `CurrentPosition` varchar(45) NOT NULL DEFAULT '',
  `StartTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `SendTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ReceiveTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `EndTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Status` int(11) NOT NULL DEFAULT '1',
  `Canceled` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`DeliveryId`),
  KEY `PACKAGEID_OF_PACKAGE_FROM_DELIVERY_idx` (`PackageId`),
  KEY `USERID_OF_USER_FROM_DELIVERY_idx` (`DriverId`),
  CONSTRAINT `PACKAGEID_OF_PACKAGE_FROM_DELIVERY` FOREIGN KEY (`PackageId`) REFERENCES `Package` (`PackageId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `USERID_OF_USER_FROM_DELIVERY` FOREIGN KEY (`DriverId`) REFERENCES `User` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Delivery`
--

LOCK TABLES `Delivery` WRITE;
/*!40000 ALTER TABLE `Delivery` DISABLE KEYS */;
INSERT INTO `Delivery` VALUES (1,1,'test-driver0','37.4035381 127.1097496','2018-10-10 22:38:27','2018-10-10 22:38:27','2018-10-10 22:38:27','2018-10-10 22:38:27',2,0),(7,10,'test-driver0','37.4035381 127.1097496','2018-10-14 18:25:07','2018-10-14 18:25:07','2018-10-14 18:25:07','2018-10-14 18:25:07',3,0),(9,4,'test-driver0','37.4035381 127.1097496','2018-10-14 18:27:05','2018-10-14 18:27:05','2018-10-14 18:27:05','2018-10-14 18:27:05',4,0),(20,24,'test-driver0','37.4035381 127.1097496','2018-11-14 04:43:33','2018-11-14 04:43:33','2018-11-14 04:43:33','2018-11-14 04:43:33',4,0),(21,26,'test-driver0','37.4035381 127.1097496','2018-11-14 05:46:45','2018-11-14 05:46:45','2018-11-14 05:46:45','2018-11-14 05:46:45',4,0),(22,25,'test-driver0','37.4035381 127.1097496','2018-11-23 07:23:42','2018-11-23 07:23:42','2018-11-23 07:23:42','2018-11-23 07:23:42',1,0),(23,28,'test-driver0','37.4035381 127.1097496','2018-11-23 07:26:42','2018-11-23 07:26:42','2018-11-23 07:26:42','2018-11-23 07:26:42',3,0),(37,30,'test-driver0','37.4035381 127.1097496','2018-11-28 01:22:59','2018-11-28 01:22:59','2018-11-28 01:22:59','2018-11-28 01:22:59',1,0),(38,29,'test-driver0','37.4035381 127.1097496','2018-11-28 01:24:39','2018-11-28 01:24:39','2018-11-28 01:24:39','2018-11-28 01:24:39',1,0),(39,32,'test-driver0','37.4035381 127.1097496','2018-11-28 01:33:54','2018-11-28 01:33:54','2018-11-28 01:33:54','2018-11-28 01:33:54',3,0),(40,33,'test-driver0','37.4035381 127.1097496','2018-11-28 02:03:08','2018-11-28 02:03:08','2018-11-28 02:03:08','2018-11-28 02:03:08',4,0);
/*!40000 ALTER TABLE `Delivery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Image`
--

DROP TABLE IF EXISTS `Image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Image` (
  `ImageId` int(11) NOT NULL AUTO_INCREMENT,
  `PackageId` int(11) NOT NULL,
  `Length` int(11) NOT NULL,
  PRIMARY KEY (`ImageId`),
  KEY `PACKAGEID_OF_PACKAGE_FROM_IMAGE_idx` (`PackageId`),
  CONSTRAINT `PACKAGEID_OF_PACKAGE_FROM_IMAGE` FOREIGN KEY (`PackageId`) REFERENCES `Package` (`PackageId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Image`
--

LOCK TABLES `Image` WRITE;
/*!40000 ALTER TABLE `Image` DISABLE KEYS */;
INSERT INTO `Image` VALUES (22,1,3731482),(23,24,54080),(24,24,606901),(25,24,566029),(26,24,422015),(27,24,233978),(28,24,531481),(29,26,7113325),(30,26,8144808),(31,26,56570),(32,26,369650),(33,26,92709),(34,26,3988956),(35,26,867298);
/*!40000 ALTER TABLE `Image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Package`
--

DROP TABLE IF EXISTS `Package`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Package` (
  `PackageId` int(11) NOT NULL AUTO_INCREMENT,
  `SenderId` varchar(45) NOT NULL,
  `ReceiverName` varchar(45) NOT NULL,
  `ReceiverPhone` varchar(45) NOT NULL,
  `SenderAddressA` varchar(255) NOT NULL,
  `SenderAddressB` varchar(255) NOT NULL,
  `ReceiverAddressA` varchar(255) NOT NULL,
  `ReceiverAddressB` varchar(255) NOT NULL,
  `Distance` int(11) NOT NULL,
  `Weight` int(11) NOT NULL,
  `Price` int(11) NOT NULL,
  `Deadline` tinyint(4) NOT NULL,
  `Canceled` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`PackageId`),
  KEY `UserId_From_Package_idx` (`SenderId`),
  CONSTRAINT `UserId_OF_USER_From_Package` FOREIGN KEY (`SenderId`) REFERENCES `User` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Package`
--

LOCK TABLES `Package` WRITE;
/*!40000 ALTER TABLE `Package` DISABLE KEYS */;
INSERT INTO `Package` VALUES (1,'test-user0','홍길동','010-2947-2193','서울시 강북구 수유동 528-12','수유아파트 102동 1004호','서울시 중구 필동 21-1','충무빌라 3동 101호',1200,1,5000,3,0),(2,'test-user0','홍길동','010-2947-2193','서울시 강북구 수유동 528-12','수유아파트 102동 1004호','서울시 중구 필동 21-1','충무빌라 3동 101호',1200,2,5000,1,0),(3,'test-user0','홍길동','010-2947-2193','서울시 강북구 수유동 528-12','수유아파트 102동 1004호','서울시 중구 필동 21-1','충무빌라 3동 101호',1200,1,5000,2,0),(4,'test-user1','홍길동','010-2947-2193','서울시 강북구 수유동 528-12','수유아파트 102동 1004호','서울시 중구 필동 21-1','충무빌라 3동 101호',1200,1,5000,4,0),(10,'test-user0','리','010-2947-2193','서울시 중구','수유아파트 102동 1004호','서울시 강남구','충무빌라 3동 101호',5500,4,0,5,0),(11,'test-user0','박성준','010-2947-2193','서울특별시 성동구 금호동','삼성래미안','서울특별시 중구 필동','동국대학교',2790,0,1000,0,0),(12,'test-user0','김하은','010-2947-2193','서울특별시 노원','노원역','울산광역시 태화동','동부아파트',248840,0,20000,0,0),(13,'test-user0','아무개','010-2947-2193','서울특별시 중구 필동','동국대학교','울산광역시 태화동','동부아파트',255350,1,8000,0,0),(15,'test-user0','Lee','010-2947-2193','서울',' ','부산',' ',233400,0,4000,0,0),(16,'test-user0','박성준','010-3235-0370','경기도 부천시 소사구','심곡본동','서울특별시 중구','필동',24050,4,300,0,0),(17,'ims21c','돼지와함께춤을','010-2947-2222','서울특별시 도봉구','쌍문동 525-1','서울특별시 중구','필동 17-1',2150,4,5000,7,0),(24,'User','소나무','010-2947-2193','서울특별시 도봉구','쌍문동 525-5','서울특별시 중구','필동 12-3',2880,2,8000,0,0),(25,'test-driver0','소나무','010-2947-2193','서울특별시 도봉구','쌍문동 525-5','서울특별시 중구','필동 17-2',2820,0,8000,7,0),(26,'User-test0','소나무','010-2947-2193','서울특별시 도봉구','쌍문동 525-6','서울특별시 중구','필동 17-2',2860,1,10000,7,0),(27,'abcd','김희오진','010-3235-0370','서울특별시 중구','어딘가','서울특별시 강남구','어딘가',6920,0,3000,0,0),(28,'hjkim','김하은','010-1111-1111','서울특별시 성동구 금호동','삼성래미안아파트','서울특별시 잠실','잠실타워',8390,0,0,0,0),(29,'test-user0','a','010-5240-7054','a','a','a','a',0,0,0,0,0),(30,'test-user0','a','010-5240-7054','a','a','a','a',0,0,0,0,0),(31,'test-user0','박성준','010-3235-0370','서울특별시 종로구','어딘가','경기도 부천시 소사구','어딘가2',19960,0,3000,0,0),(32,'test-user0','박성준','010-3235-0370','강원도 원주시','테스트1','경기도 부천시','테스트2',127810,0,1111,0,0),(33,'Customer','심희오','010-2947-2193','서울특별시 중구','장충동2가 26-1','서울특별시 성동구','금호동1가 1500',2520,1,5000,5,0);
/*!40000 ALTER TABLE `Package` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `User` (
  `UserId` varchar(45) NOT NULL,
  `UserPw` varchar(45) NOT NULL,
  `UserName` varchar(45) NOT NULL,
  `UserPhone` varchar(45) NOT NULL,
  `Authorized` tinyint(4) NOT NULL DEFAULT '-1',
  `CurrentPosition` varchar(45) NOT NULL DEFAULT '0 0',
  `DefaultAddressA` varchar(255) NOT NULL,
  `DefaultAddressB` varchar(255) NOT NULL,
  PRIMARY KEY (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES ('abcd','*A154C52565E9E7F94BFC08A1FE702624ED8EFFDA','박성준','010-3235-0370',0,'0 0','',''),('Customer','*71863C254516DFEB4FF64B27BA21FF236947E535','사용자','010-6488-6798',-1,'37.5581674 126.9984832','서울특별시 중구','장충동2가 26-1'),('hjkim','*A4B6157319038724E3560894F7F932C8886EBFCF','김희진','010-6488-6798',0,'37.5581589 126.9985058','',''),('im','*DC288514A4097308DAF3D81BBC218518D64C6E7D','심파셀','010-2947-2193',-1,'37.4933784 126.8974593','',''),('ims21c','*DDB2524BA19B8DB0B05AC10AD3E6EE04DDCDEEB9','심희오','010-2947-2193',-1,'37.487384532033076 126.89072523225592','',''),('test-driver0','*22EB7D0B4F6EE358F48E73E1BF81952C4CA80BB7','테스트 드라이버0','010-2947-2193',1,'37.4035381 127.1097496','',''),('test-driver1','*800899D05779C97098B6EF1D92DE1C8434F03734','테스트 드라이버1','010-2947-2193',-1,'0 0','',''),('test-user0','*A458DFCC4A3AA977119BF621D13FDF18F421C3F7','테스트 사용자0','010-2947-2193',0,'37.4035936 127.1100108','',''),('test-user1','*666AD8B646320A95E855964C905CFC565568EAFE','테스트 사용자1','010-2947-2193',-1,'0 0','',''),('test-user2','*B83F5136E50434FCCE76894809AC2341090A97B3','test-user2','010-5240-7054',-1,'0 0','test-user2','test-user2'),('tttt','*695920EF99FD542BA8262088F0C278AEF0ADDDA5','박성준','010-3235-0370',0,'0 0','',''),('User','*D5D9F81F5542DE067FFF5FF7A4CA4BDD322C578F','소나무','010-2947-2193',0,'37.4847394 126.9711774','',''),('user-test0','*D5D9F81F5542DE067FFF5FF7A4CA4BDD322C578F','User','010-2947-2193',0,'37.5582437 126.9983833','',''),('User0','*D5D9F81F5542DE067FFF5FF7A4CA4BDD322C578F','User','010-2947-2193',-1,'0 0','',''),('wwlwwowwn12','*7BA84A29639EF707FF299ECF7D44679BB6F14655','이재우','010-8968-6786',-1,'37.5614575 126.9975011','','');
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-02  8:54:46
