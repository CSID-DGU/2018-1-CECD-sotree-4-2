import * as express from "express";
import {router} from "./router";
import * as morgan from "morgan";
import {join} from "path";
import {logger} from "./Logger";

const app = express();

const port = process.env.PORT !== undefined ? parseInt(process.env.PORT, 10) : 3000;

app.use(morgan(logger));
app.use((req, res, next) => {
    res.set({
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, POST, PATCH, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type"
    });

    next();
});

app.get("/page/static/js/bundle.js", (req, res) => {
    res.sendFile(join(__dirname, "../page/static/js/bundle.js"));
});

app.get("/page/*", (req, res) => {
    res.sendFile(join(__dirname, "../page/index.html"));
});

app.get("/map/static/js/bundle.js", (req, res) => {
    res.sendFile(join(__dirname, "../page/static/js/bundle.js"));
});

app.get("/map/*", (req, res) => {
    res.sendFile(join(__dirname, "../page/index.html"));
});

app.get("/admin/static/js/bundle.js", (req, res) => {
    res.sendFile(join(__dirname, "../page/static/js/bundle.js"));
});

app.get("/admin/*", (req, res) => {
    res.sendFile(join(__dirname, "../page/index.html"));
});

app.use(router);

app.listen(port, () => {
    console.log(`Server is listening on PORT ${port}`);
});
