export const logger = (tokens, req, res) => {
    const date = new Date();
    const timezoneOffset = date.getTimezoneOffset() * 60000;

    const dateWithTimezone = new Date(date.getTime() - timezoneOffset).toISOString().substring(0, 19).replace("T", " ");
    const timezone = date.toString().split(" ")[5];

    const status = tokens.status(req, res);

    let statusWIthColor = "";

    if (status !== undefined && status !== null) {
        switch (status.substring(0, 1)) {
            case "1":
            case "2":
                statusWIthColor = `\x1b[32m${status}\x1b[0m`;
                break;
            case "3":
                statusWIthColor = `\x1b[36m${status}\x1b[0m`;
                break;
            case "4":
            case "5":
                statusWIthColor = `\x1b[31m${status}\x1b[0m`;
                break;
            default:
                statusWIthColor = status;
        }
    } else {
        statusWIthColor = `\x1b[31m${status}\x1b[0m`;
    }

    return [
        [
            `\x1b[95m${dateWithTimezone} ${timezone}\x1b[0m`,
            `[from ${tokens["remote-addr"](req, res)}]`,
            tokens.method(req, res),
            tokens.url(req, res),
            statusWIthColor,
            `(${tokens["response-time"](req, res)}ms)`
        ].join(" "),
        `Headers: ${JSON.stringify(req.headers)}`,
        `Body: ${JSON.stringify(req.body)}`
    ].join("\n");
};
