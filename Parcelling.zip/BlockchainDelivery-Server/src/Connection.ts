import * as mysql from "mysql";
import {MysqlError} from "mysql";

export class Connection {
    private connection: mysql.Connection;

    public constructor() {
        this.connection = mysql.createConnection({
            host: process.env.DB_HOST,
            port: process.env.DB_PORT !== undefined ? parseInt(process.env.DB_PORT, 10) : 3306,
            user: process.env.DB_USER,
            password: process.env.DB_PASSWORD,
            database: process.env.DB_DATABASE
        });
    }

    public query(query: string) {
        return new Promise((resolve, reject) => {
            this.connection.query(query, (err: MysqlError, results?: any) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(results);
                }
            });
        });
    }

    public destroy() {
        return this.connection.destroy();
    }
}
