export interface IUser {
    UserId: string,
    UserPw: string,
    UserName: string
}