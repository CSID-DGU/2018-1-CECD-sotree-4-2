export interface IPackageWithProgress {
    packageId: number,
    senderId: string,
    receiverName: number,
    senderAddressA: string,
    senderAddressB: string,
    receiverAddressA: string,
    receiverAddressB: string,
    distance: number,
    weight: number, // 0: 2kg 이하, 1: 5kg 이하, 2: 10kg 이하, 3: 20kg 이하, 4:30kg 이하
    price: number,
    deadline: number, // 0: 3시간, 1: 6시간, 2: 9시간, 3: 12시간, 4: 15시간, 5: 18시간, 6: 21시간, 7: 24시간
    canceled: boolean,
    driverId: string,
    status: number,
    currentPosition: string
}

export interface IPackageWithoutProgress {
    packageId: number,
    senderId: string,
    receiverName: number,
    senderAddressA: string,
    senderAddressB: string,
    receiverAddressA: string,
    receiverAddressB: string,
    distance: number,
    weight: number, // 0: 2kg 이하, 1: 5kg 이하, 2: 10kg 이하, 3: 20kg 이하, 4:30kg 이하
    price: number,
    deadline: number, // 0: 3시간, 1: 6시간, 2: 9시간, 3: 12시간, 4: 15시간, 5: 18시간, 6: 21시간, 7: 24시간
    canceled: boolean
}
