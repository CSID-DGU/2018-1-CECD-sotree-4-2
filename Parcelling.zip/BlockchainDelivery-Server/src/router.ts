import * as express from "express";
import {Controllers} from "./Contollers";
import * as bodyParser from "body-parser";

const router = express.Router();

// 로그인
router.post("/login", bodyParser.json(), Controllers.login);

// 가입
router.post("/users", bodyParser.json(), Controllers.postUser);

// 인증 파일 전송
router.post("/users/:userId/auth", bodyParser.raw({type: "application/octet-stream", limit: "10mb"}), Controllers.postAuthorizationFile);

// 배달 가능 택배
router.get("/packages/available", bodyParser.json(), Controllers.getAvailablePackages);

// 특정인이 보낸 택배
router.get("/packages/by-sender/:senderId", bodyParser.json(), Controllers.getPackagesBySender);

// 특정인이 보낸 택배.진행중
router.get("/packages/by-sender/:senderId/progress", bodyParser.json(), Controllers.getProgressPackagesBySender);

// 특정인이 보낸 택배.끝남
router.get("/packages/by-sender/:senderId/finished", bodyParser.json(), Controllers.getFinishedPackagesBySender);

// 특정인이 배달한 택배.진행중
router.get("/packages/by-driver/:driverId/progress", bodyParser.json(), Controllers.getProgressPackagesByDriver);

// 특정인이 배달한 택배.끝남
router.get("/packages/by-driver/:driverId/finished", bodyParser.json(), Controllers.getFinishedPackagesByDriver);

// 택배 등록
router.post("/packages", bodyParser.json(), Controllers.postPackages);

// 택배 이미지 등록
router.post("/packages/:packageId/images", bodyParser.raw({type: "application/octet-stream", limit: "10mb"}), Controllers.postImages);

// 배달 실행
router.post("/delivery", bodyParser.json(), Controllers.postDelivery);

// 배달중인 정보 가져오기
router.get("/delivery/:deliveryId", bodyParser.json(), Controllers.getDetails);

router.get("/delivery/:deliveryId/status", bodyParser.json(), Controllers.getDeliveryStatus);

// 배달 정보 수정 (상태 변경)
router.patch("/delivery/:deliveryId", bodyParser.json(), Controllers.patchDelivery);

// 위치 등록
router.patch("/position/:driverId", bodyParser.json(), Controllers.patchCurrentPosition);

export {router as router};