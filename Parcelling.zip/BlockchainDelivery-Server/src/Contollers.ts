import * as express from "express";
import {existsSync, mkdirSync, readdirSync, readFileSync, writeFileSync} from "fs";
import {IPackageWithoutProgress, IPackageWithProgress} from "./Interfaces/IPackage";
import {Connection} from "./Connection";
import {MysqlError} from "mysql";
import * as request from "request";
import {extname, join} from "path";

const imagePath = join(__dirname, "../image");
const authorizationPath = join(__dirname, "../authorization");

const login = (req: express.Request, res: express.Response) => {
    const userId = encodeURI(req.body.userId.replace(/[\r\n]/g, ""));
    const userPw = encodeURI(req.body.userPw.replace(/[\r\n]/g, ""));

    const connection = new Connection();
    connection
        .query(`SELECT 0<COUNT(*) AS userIdAvailable, UserPw=PASSWORD('${userPw}') AS userPwAvailable, UserName AS userName, UserPhone AS userPhone, Authorized AS authorized, DefaultAddressA AS defaultAddressA, DefaultAddressB AS defaultAAddressB FROM User WHERE UserId='${userId}'`)
        .then((result: any[]) => {
            if (result[0].userIdAvailable === 0) {
                res
                    .status(404)
                    .end();
            } else if (result[0].userPwAvailable === 0) {
                res
                    .status(401)
                    .end();
            } else {
                res
                    .status(201)
                    .json({
                        userName: result[0].userName,
                        userPhone: result[0].userPhone,
                        authorized: result[0].authorized
                    });
            }

            connection.destroy();
        })
        .catch((err: MysqlError) => {
            console.error(err);

            res
                .status(500)
                .json(err);

            connection.destroy();
        });
};

const postUser = (req: express.Request, res: express.Response) => {
    const userId = req.body.userId;
    const userPw = req.body.userPw;
    const userName = req.body.userName;
    const userPhone = req.body.userPhone;
    const defaultAddressA = req.body.defaultAddressA;
    const defaultAddressB = req.body.defaultAddressB;

    const connection = new Connection();
    connection
        .query(`INSERT INTO User(UserId, UserPw, UserName, UserPhone, DefaultAddressA, DefaultAddressB) VALUES ('${userId}', PASSWORD('${userPw}'), '${userName}', '${userPhone}', '${defaultAddressA}', '${defaultAddressB}')`)
        .then(() => {
            res
                .status(201)
                .end();

            connection.destroy();
        })
        .catch((err: MysqlError) => {
            if (err.errno === 1062) {
                res
                    .status(409)
                    .end();
            } else {
                console.error(err);

                res
                    .status(500)
                    .json(err);
            }

            connection.destroy();
        });
};

const postAuthorizationFile = (req: express.Request, res: express.Response) => {
    if (!existsSync(authorizationPath)) {
        mkdirSync(authorizationPath);
    }

    writeFileSync(join(authorizationPath, `/${req.params.userId}.${req.headers["x-content-encoding"]}`), req.body);

    const connection = new Connection();
    connection
        .query(`UPDATE User SET Authorized=0 WHERE UserId='${req.params.userId}'`)
        .then(() => {
            res
                .status(204)
                .end();

            connection.destroy();
        })
        .catch((err: MysqlError) => {
            console.error(err);

            res
                .status(500)
                .json(err);

            connection.destroy();
        });

    res
        .status(201)
        .end();
};

const getAvailablePackages = (req: express.Request, res: express.Response) => {
    const connection = new Connection();
    connection
        .query(`SELECT PackageId AS packageId, SenderId AS senderId, ReceiverName AS receiverName, SenderAddressA AS senderAddressA, SenderAddressB AS senderAddressB, ReceiverAddressA AS receiverAddressA, ReceiverAddressB AS receiverAddressB, Distance AS distance, Weight AS weight, Price AS price, UNIX_TIMESTAMP(Deadline) AS deadline, Canceled AS canceled FROM Package WHERE Package.PackageId NOT IN (SELECT PackageId From Delivery WHERE Canceled=FALSE)`)
        .then((result: IPackageWithoutProgress[]) => {
            res
                .status(200)
                .json({
                    data: result
                        .map(value => ({
                            deliveryId: 0,
                            driverId: "",
                            status: 0,
                            currentPosition: "0 0",
                            ...value
                        }))
                        .sort((a, b) => {
                            const weightA = a.distance * -0.1 + a.weight * -225 * a.deadline * 90 + a.price * 0.1;
                            const weightB = b.distance * -0.1 + b.weight * -225 * b.deadline * 90 + b.price * 0.1;

                            if (weightA < weightB) {
                                return 1;
                            } else if (weightA > weightB) {
                                return -1;
                            } else {
                                return 0;
                            }
                        })
                });

            connection.destroy();
        })
        .catch((err: MysqlError) => {
            console.error(err);

            res
                .status(500)
                .json(err);

            connection.destroy();
        });
};

const getPackagesBySender = (req: express.Request, res: express.Response) => {
    const packages: IPackageWithProgress[] = [];

    const connection = new Connection();
    connection
        .query(`SELECT Delivery.DeliveryId AS deliveryId, Package.PackageId AS packageId, Package.SenderId AS senderId, Package.ReceiverName AS receiverName, Package.ReceiverPhone AS receiverPhone, Package.SenderAddressA AS senderAddressA, Package.SenderAddressB AS senderAddressB, Package.ReceiverAddressA AS receiverAddressA, Package.ReceiverAddressB AS receiverAddressB, Package.Distance AS distance, Package.Weight AS weight, Package.Price AS price, UNIX_TIMESTAMP(Package.Deadline) AS deadline, Package.Canceled AS canceled, Delivery.DriverId AS driverId, Delivery.Status AS status, User.CurrentPosition AS currentPosition FROM Package, Delivery, User WHERE Package.SenderId='${req.params.senderId}' AND Package.PackageId=Delivery.PackageId AND Delivery.Canceled=FALSE AND User.UserId=Delivery.DriverId`)
        .then((result: IPackageWithProgress[]) => {
            packages.push(...result);

            return connection
                .query(`SELECT Package.PackageId AS packageId, Package.SenderId AS senderId, Package.ReceiverName AS receiverName, Package.ReceiverPhone AS receiverPhone, Package.SenderAddressA AS senderAddressA, Package.SenderAddressB AS senderAddressB, Package.ReceiverAddressA AS receiverAddressA, Package.ReceiverAddressB AS receiverAddressB, Package.Distance AS distance, Package.Weight AS weight, Package.Price AS price, UNIX_TIMESTAMP(Package.Deadline) AS deadline, Package.Canceled AS canceled FROM Package WHERE Package.SenderId='${req.params.senderId}' AND Package.PackageId NOT IN (SELECT PackageId FROM Delivery WHERE Delivery.Canceled!=TRUE)`);
        })
        .then((result: IPackageWithoutProgress[]) => {
            packages.push(...result.map(value => ({
                deliveryId: 0,
                driverId: "",
                status: 0,
                currentPosition: "0 0",
                ...value
            })));

            res
                .status(200)
                .json({
                    data: packages
                });

            connection.destroy();
        })
        .catch((err: MysqlError) => {
            console.error(err);

            res
                .status(500)
                .json(err);

            connection.destroy();
        });
};

const getProgressPackagesBySender = (req: express.Request, res: express.Response) => {
    const connection = new Connection();
    connection
        .query(`SELECT Delivery.DeliveryId AS deliveryId, Package.PackageId AS packageId, Package.SenderId AS senderId, Package.ReceiverName AS receiverName, Package.ReceiverPhone AS receiverPhone, Package.SenderAddressA AS senderAddressA, Package.SenderAddressB AS senderAddressB, Package.ReceiverAddressA AS receiverAddressA, Package.ReceiverAddressB AS receiverAddressB, Package.Distance AS distance, Package.Weight AS weight, Package.Price AS price, UNIX_TIMESTAMP(Package.Deadline) AS deadline, Package.Canceled AS canceled, Delivery.DriverId AS driverId, Delivery.Status AS status, User.CurrentPosition AS currentPosition FROM Package, Delivery, User WHERE Package.SenderId='${req.params.senderId}' AND Package.PackageId=Delivery.PackageId AND Delivery.Canceled=FALSE AND Delivery.Status!=4 AND User.UserId=Delivery.DriverId`)
        .then((result: IPackageWithProgress[]) => {
            res
                .status(200)
                .json({
                    data: result
                });

            connection.destroy();
        })
        .catch((err: MysqlError) => {
            console.error(err);

            res
                .status(500)
                .json(err);

            connection.destroy();
        });
};

const getProgressPackagesByDriver = (req: express.Request, res: express.Response) => {
    const connection = new Connection();
    connection
        .query(`SELECT Delivery.DeliveryId AS deliveryId, Package.PackageId AS packageId, Package.SenderId AS senderId, Package.ReceiverName AS receiverName, Package.ReceiverPhone AS receiverPhone, Package.SenderAddressA AS senderAddressA, Package.SenderAddressB AS senderAddressB, Package.ReceiverAddressA AS receiverAddressA, Package.ReceiverAddressB AS receiverAddressB, Package.Distance AS distance, Package.Weight AS weight, Package.Price AS price, UNIX_TIMESTAMP(Package.Deadline) AS deadline, Package.Canceled AS canceled, Delivery.DriverId AS driverId, Delivery.Status AS status, User.CurrentPosition AS currentPosition FROM Package, Delivery, User WHERE Delivery.DriverId='${req.params.driverId}' AND Package.PackageId=Delivery.PackageId AND Delivery.Canceled=FALSE AND Delivery.Status!=4 AND User.UserId=Delivery.DriverId`)
        .then((result: IPackageWithProgress[]) => {
            res
                .status(200)
                .json({
                    data: result
                });

            connection.destroy();
        })
        .catch((err: MysqlError) => {
            console.error(err);

            res
                .status(500)
                .json(err);

            connection.destroy();
        });
};

const getFinishedPackagesBySender = (req: express.Request, res: express.Response) => {
    const connection = new Connection();
    connection
        .query(`SELECT Delivery.DeliveryId AS deliveryId, Package.PackageId AS packageId, Package.SenderId AS senderId, Package.ReceiverName AS receiverName, Package.ReceiverPhone AS receiverPhone, Package.SenderAddressA AS senderAddressA, Package.SenderAddressB AS senderAddressB, Package.ReceiverAddressA AS receiverAddressA, Package.ReceiverAddressB AS receiverAddressB, Package.Distance AS distance, Package.Weight AS weight, Package.Price AS price, UNIX_TIMESTAMP(Package.Deadline) AS deadline, Package.Canceled AS canceled, Delivery.DriverId AS driverId, Delivery.Status AS status, User.CurrentPosition AS currentPosition FROM Package, Delivery, User WHERE Package.SenderId='${req.params.senderId}' AND Package.PackageId=Delivery.PackageId AND Delivery.Canceled=FALSE AND Delivery.Status=4 AND User.UserId=Delivery.DriverId`)
        .then((result: IPackageWithProgress[]) => {
            res
                .status(200)
                .json({
                    data: result
                });

            connection.destroy();
        })
        .catch((err: MysqlError) => {
            console.error(err);

            res
                .status(500)
                .json(err);

            connection.destroy();
        });
};

const getFinishedPackagesByDriver = (req: express.Request, res: express.Response) => {
    const connection = new Connection();
    connection
        .query(`SELECT Delivery.DeliveryId AS deliveryId, Package.PackageId AS packageId, Package.SenderId AS senderId, Package.ReceiverName AS receiverName, Package.SenderAddressA AS senderAddressA, Package.SenderAddressB AS senderAddressB, Package.ReceiverAddressA AS receiverAddressA, Package.ReceiverAddressB AS receiverAddressB, Package.Distance AS distance, Package.Weight AS weight, Package.Price AS price, UNIX_TIMESTAMP(Package.Deadline) AS deadline, Package.Canceled AS canceled, Delivery.DriverId AS driverId, Delivery.Status AS status, User.CurrentPosition AS currentPosition FROM Package, Delivery, User WHERE Delivery.DriverId='${req.params.driverId}' AND Package.PackageId=Delivery.PackageId AND Delivery.Canceled=FALSE AND Delivery.Status=4 AND User.UserId=Delivery.DriverId`)
        .then((result: IPackageWithProgress[]) => {
            res
                .status(200)
                .json({
                    data: result
                });

            connection.destroy();
        })
        .catch((err: MysqlError) => {
            console.error(err);

            res
                .status(500)
                .json(err);

            connection.destroy();
        });
};

const postPackages = (req: express.Request, res: express.Response) => {
    const senderId = req.body.senderId;
    const receiverName = req.body.receiverName;
    const receiverPhone = req.body.receiverPhone;
    const senderAddressA = req.body.senderAddressA;
    const senderAddressB = req.body.senderAddressB;
    const receiverAddressA = req.body.receiverAddressA;
    const receiverAddressB = req.body.receiverAddressB;
    const distance = req.body.distance;
    const weight = req.body.weight;
    const price = req.body.price;
    const deadline = req.body.deadline;

    const connection = new Connection();
    connection
        .query(`INSERT INTO Package (SenderId, ReceiverName, ReceiverPhone, SenderAddressA, SenderAddressB, ReceiverAddressA, ReceiverAddressB, Distance, Weight, Price, Deadline) VALUES ('${senderId}', '${receiverName}', '${receiverPhone}', '${senderAddressA}', '${senderAddressB}', '${receiverAddressA}', '${receiverAddressB}', ${distance}, ${weight}, ${price}, ${deadline})`)
        .then(() => {
            return connection
                .query(`SELECT PackageId AS packageId FROM Package ORDER BY SenderId DESC LIMIT 1`);
        })
        .then((result: { packageId: number }[]) => {
            res
                .status(201)
                .json({
                    data: result[0]
                });

            connection.destroy();
        })
        .catch((err: MysqlError) => {
            console.error(err);

            res
                .status(500)
                .json(err);

            connection.destroy();
        });
};

const getDetails = (req: express.Request, res: express.Response) => {
    let endTime = 0;

    const connection = new Connection();
    connection
        .query(`SELECT UNIX_TIMESTAMP(EndTime) AS endTime FROM Delivery where DeliveryId=${req.params.deliveryId}`)
        .then((result: any[]) => {
            endTime = result[0].endTime;

            return connection
                .query(`SELECT Image.ImageId AS imageId FROM Delivery, Image where Image.PackageId=Delivery.PackageId AND Delivery.DeliveryId=${req.params.deliveryId} ORDER BY imageId ASC`);
        })
        .then((result: any[]) => {
            if (result.length == 0) {
                res
                    .status(200)
                    .set({
                        "x-date": endTime
                    })
                    .end();
            } else {
                const fileName = readdirSync(imagePath)
                    .find(value => {
                        return value.startsWith(`${result[0].imageId}.`);
                    });
                const ext = extname(fileName);

                res
                    .status(200)
                    .set({
                        "x-date": endTime,
                        "x-content-encoding": ext.substring(1),
                        "content-type": "application/octet-stream"
                    })
                    .send(readFileSync(join(imagePath, fileName)));
            }

            connection.destroy();
        })
        .catch((err: MysqlError) => {
            console.error(err);

            res
                .status(500)
                .json(err);

            connection.destroy();
        });
};

const postImages = (req: express.Request, res: express.Response) => {
    const packageId = req.params.packageId;

    if (!existsSync(imagePath)) {
        mkdirSync(imagePath);
    }

    const connection = new Connection();
    connection
        .query(`INSERT INTO Image (PackageId, Length) VALUES (${packageId}, ${req.body.length})`)
        .then(() => {
            return connection
                .query(`SELECT ImageId AS imageId FROM Image WHERE PackageId=${packageId} AND Length=${req.body.length}`);
        })
        .then((result: { imageId: number }[]) => {
            writeFileSync(join(imagePath, `${result[0].imageId}.${req.headers["x-content-encoding"]}`), req.body);

            res
                .status(204)
                .end();

            connection.destroy();
        })
        .catch((err: MysqlError) => {
            console.error(err);

            res
                .status(500)
                .json(err);

            connection.destroy();
        });
};

const postDelivery = (req: express.Request, res: express.Response) => {
    const packageId = req.body.packageId;
    const driverId = req.body.userId;

    let senderId = "";
    let senderName = "";
    let senderPhone = "";
    let driverName = "";
    let driverPhone = "";

    const connection = new Connection();

    return connection
        .query(`SELECT Sender.UserId AS senderId, Sender.UserName AS senderName, Sender.UserPhone AS senderPhone, Driver.UserName AS driverName, Driver.UserPhone AS driverPhone FROM User AS Sender, User AS Driver, Package WHERE Sender.UserId=Package.SenderId AND Package.PackageId=${packageId} AND Driver.UserId='${driverId}'`)
        .then((result: any[]) => {
            senderId = result[0].senderId;
            senderName = result[0].senderName;
            senderPhone = result[0].senderPhone;
            driverName = result[0].driverName;
            driverPhone = result[0].driverPhone;

            return new Promise((resolve, reject) => {
                request
                    .post({
                        url: "https://sms.gabia.com/oauth/token",
                        headers: {
                            "Authorization": "Basic dGxhdG5xa2Q6NDE2Y2JjMzUyNTJlM2UwNzA3NmFkMzJmN2FlMzVjYzI=",
                            "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
                        },
                        form: {
                            grant_type: "client_credentials"
                        }
                    }, (error, response, body) => {
                        if (error) {
                            reject(error);
                        } else {
                            resolve(body);
                        }
                    });
            });
        })
        .then((response: any) => {
            return new Promise((resolve, reject) => {
                request
                    .post({
                        url: "https://sms.gabia.com/api/send/lms",
                        headers: {
                            "Authorization": `Basic ${Buffer.from(`tlatnqkd:${JSON.parse(response).access_token}`).toString("base64")}`,
                            "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
                        },
                        form: {
                            phone: senderPhone,
                            callback: "010-2947-2193",
                            message: `${senderName} 고객님, 안녕하세요. ${driverName} 배송인(${driverPhone})이 택배 인계를 위해 이동중입니다.`,
                            reqdate: 0
                        }
                    }, (error, response, body) => {
                        if (error) {
                            reject(error);
                        } else {
                            resolve(body);
                        }
                    });
            });
        })
        .then(response => {
            return connection
                .query(`INSERT INTO Delivery(PackageId, DriverId) VALUES('${packageId}', '${driverId}')`);
        })
        .then(() => {
            connection.destroy();

            res
                .status(201)
                .end();
        })
        .catch((err: MysqlError) => {
            console.error(err);

            res
                .status(500)
                .json(err);

            connection.destroy();
        });
};

const patchDelivery = (req: express.Request, res: express.Response) => {
    const connection = new Connection();
    connection
        .query(`UPDATE Delivery SET Status=${req.body.status} WHERE DeliveryId='${req.params.deliveryId}'`)
        .then(result => {
            let senderId = "";
            let senderName = "";
            let senderPhone = "";
            let driverId = "";
            let driverName = "";
            let driverPhone = "";
            let receiverName = "";
            let receiverPhone = "";
            let receiverAddressA = "";
            let receiverAddressB = "";

            switch (req.body.status) {
                case 2:
                    return connection
                        .query(`SELECT Sender.UserId AS senderId, Sender.UserName AS senderName, Sender.UserPhone AS SenderPhone, Driver.UserId AS driverId, Driver.UserName AS driverName, Driver.UserPhone AS driverPhone, Package.SenderId AS senderId, Package.ReceiverName AS receiverName, Package.ReceiverPhone AS receiverPhone, Package.ReceiverPhone AS receiverPhone, Package.ReceiverAddressA AS receiverAddressA, Package.ReceiverAddressB AS receiverAddressB FROM Package, Delivery, User AS Sender, User AS Driver WHERE Sender.UserId=Package.SenderId AND Driver.UserId=Delivery.DriverId AND Delivery.PackageId=Package.PackageId AND Delivery.DeliveryId=${req.params.deliveryId}`)
                        .then((result: any[]) => {
                            senderId = result[0].senderId;
                            senderName = result[0].senderName;
                            senderPhone = result[0].senderPhone;
                            driverId = result[0].driverId;
                            driverName = result[0].driverName;
                            driverPhone = result[0].driverPhone;
                            receiverName = result[0].receiverName;
                            receiverPhone = result[0].receiverPhone;
                            receiverAddressA = result[0].receiverAddressA;
                            receiverAddressB = result[0].receiverAddressB;

                            return new Promise((resolve, reject) => {
                                request
                                    .post({
                                        url: "https://sms.gabia.com/oauth/token",
                                        headers: {
                                            "Authorization": "Basic dGxhdG5xa2Q6NDE2Y2JjMzUyNTJlM2UwNzA3NmFkMzJmN2FlMzVjYzI=",
                                            "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
                                        },
                                        form: {
                                            grant_type: "client_credentials"
                                        }
                                    }, (error, response, body) => {
                                        if (error) {
                                            reject(error);
                                        } else {
                                            resolve(body);
                                        }
                                    });
                            });
                        })
                        .then((response: any) => {
                            return new Promise((resolve, reject) => {
                                request
                                    .post({
                                        url: "https://sms.gabia.com/api/send/lms",
                                        headers: {
                                            "Authorization": `Basic ${Buffer.from(`tlatnqkd:${JSON.parse(response).access_token}`).toString("base64")}`,
                                            "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
                                        },
                                        form: {
                                            phone: receiverPhone,
                                            callback: "010-2947-2193",
                                            message: `${receiverName} 고객님, 안녕하세요. 배송이 시작되었습니다. 배송인: ${driverName} (${driverPhone})`,
                                            reqdate: 0
                                        }
                                    }, (error, response, body) => {
                                        if (error) {
                                            reject(error);
                                        } else {
                                            resolve(body);
                                        }
                                    });
                            });
                        })
                        .then(response => {
                            connection.destroy();

                            res
                                .status(204)
                                .end();
                        })
                        .catch((err: MysqlError) => {
                            console.error(err);

                            res
                                .status(500)
                                .json(err);

                            connection.destroy();
                        });
                    break;
                case 3:
                    return connection
                        .query(`SELECT Sender.UserId AS senderId, Sender.UserName AS senderName, Sender.UserPhone AS SenderPhone, Driver.UserId AS driverId, Driver.UserName AS driverName, Driver.UserPhone AS driverPhone, Package.SenderId AS senderId, Package.ReceiverName AS receiverName, Package.ReceiverPhone AS receiverPhone, Package.ReceiverPhone AS receiverPhone, Package.ReceiverAddressA AS receiverAddressA, Package.ReceiverAddressB AS receiverAddressB FROM Package, Delivery, User AS Sender, User AS Driver WHERE Sender.UserId=Package.SenderId AND Driver.UserId=Delivery.DriverId AND Delivery.PackageId=Package.PackageId AND Delivery.DeliveryId=${req.params.deliveryId}`)
                        .then((result: any[]) => {
                            senderId = result[0].senderId;
                            senderName = result[0].senderName;
                            senderPhone = result[0].senderPhone;
                            driverId = result[0].driverId;
                            driverName = result[0].driverName;
                            driverPhone = result[0].driverPhone;
                            receiverName = result[0].receiverName;
                            receiverPhone = result[0].receiverPhone;
                            receiverAddressA = result[0].receiverAddressA;
                            receiverAddressB = result[0].receiverAddressB;

                            return new Promise((resolve, reject) => {
                                request
                                    .post({
                                        url: "https://sms.gabia.com/oauth/token",
                                        headers: {
                                            "Authorization": "Basic dGxhdG5xa2Q6NDE2Y2JjMzUyNTJlM2UwNzA3NmFkMzJmN2FlMzVjYzI=",
                                            "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
                                        },
                                        form: {
                                            grant_type: "client_credentials"
                                        }
                                    }, (error, response, body) => {
                                        if (error) {
                                            reject(error);
                                        } else {
                                            resolve(body);
                                        }
                                    });
                            });
                        })
                        .then((response: any) => {
                            return new Promise((resolve, reject) => {
                                request
                                    .post({
                                        url: "https://sms.gabia.com/api/send/lms",
                                        headers: {
                                            "Authorization": `Basic ${Buffer.from(`tlatnqkd:${JSON.parse(response).access_token}`).toString("base64")}`,
                                            "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
                                        },
                                        form: {
                                            phone: receiverPhone,
                                            callback: "010-2947-2193",
                                            message: `${receiverName} 고객님, 안녕하세요. 택배를 받으셨다면 아래 링크를 눌러 수령확인을 해주시기 바랍니다. 발송인: ${senderName} (${receiverPhone}) http://210.94.194.82:58080/page/${Buffer.from(`${req.params.deliveryId}\\${senderId}\\${receiverName}\\${receiverAddressA}\\${receiverAddressB}\\${new Date().getTime() / 1000}`).toString("base64")}`,
                                            reqdate: 0
                                        }
                                    }, (error, response, body) => {
                                        if (error) {
                                            reject(error);
                                        } else {
                                            resolve(body);
                                        }
                                    });
                            });
                        })
                        .then(response => {
                            connection.destroy();

                            res
                                .status(204)
                                .end();
                        })
                        .catch((err: MysqlError) => {
                            console.error(err);

                            res
                                .status(500)
                                .json(err);

                            connection.destroy();
                        });
                default:
                    res
                        .status(204)
                        .end();
                    break;
            }

            connection.destroy();
        })
        .catch((err: MysqlError) => {
            console.error(err);

            res
                .status(500)
                .json(err);

            connection.destroy();
        });
};

const patchCurrentPosition = (req: express.Request, res: express.Response) => {
    const connection = new Connection();
    connection
        .query(`UPDATE User SET CurrentPosition='${req.body.latitude} ${req.body.longitude}' WHERE UserId='${req.params.driverId}'`)
        .then(() => {
            return connection
                .query(`UPDATE Delivery SET CurrentPosition='${req.body.latitude} ${req.body.longitude}' WHERE DriverId='${req.params.driverId}'`);
        })
        .then(() => {
            res
                .status(204)
                .end();

            connection.destroy();
        })
        .catch((err: MysqlError) => {
            console.error(err);

            res
                .status(500)
                .json(err);

            connection.destroy();
        });
};

const getDeliveryStatus = (req: express.Request, res: express.Response) => {
    const connection = new Connection();
    connection
        .query(`SELECT Delivery.Status AS status FROM Delivery WHERE Delivery.DeliveryId=${req.params.deliveryId}`)
        .then((result: any[]) => {
            if (result.length === 0) {
                res
                    .status(404)
                    .end();
            } else {
                res
                    .status(200)
                    .json({
                        status: result[0].status
                    });
            }

            connection.destroy();
        })
        .catch((err: MysqlError) => {
            console.error(err);

            res
                .status(500)
                .json(err);

            connection.destroy();
        });
};

export const Controllers = {
    login,
    postUser,
    postAuthorizationFile,
    getAvailablePackages,
    getPackagesBySender,
    getProgressPackagesBySender,
    getProgressPackagesByDriver,
    getFinishedPackagesBySender,
    getFinishedPackagesByDriver,
    postPackages,
    getDetails,
    postImages,
    postDelivery,
    patchDelivery,
    patchCurrentPosition,
    getDeliveryStatus
};